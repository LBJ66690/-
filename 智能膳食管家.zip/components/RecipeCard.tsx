import React, { useState, useEffect } from 'react';
import { Heart, Clock, Flame, Play } from 'lucide-react';
import { Recipe } from '../types';
import { toast } from 'sonner';

interface RecipeCardProps {
  recipe: Recipe;
  onClick: (id: string) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onClick }) => {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('favorites');
    if (saved) {
      const ids = JSON.parse(saved);
      setIsFavorite(ids.includes(recipe.id));
    }
  }, [recipe.id]);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    const saved = localStorage.getItem('favorites');
    let ids: string[] = saved ? JSON.parse(saved) : [];
    
    let newFavState = false;
    if (ids.includes(recipe.id)) {
      ids = ids.filter((id: string) => id !== recipe.id);
      toast.success("已取消收藏");
    } else {
      ids.push(recipe.id);
      newFavState = true;
      toast.success("已加入收藏夹");
    }
    
    localStorage.setItem('favorites', JSON.stringify(ids));
    setIsFavorite(newFavState);
  };

  return (
    <div 
      onClick={() => onClick(recipe.id)}
      className="group bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-transparent hover:border-brand-100 dark:hover:border-brand-900"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={recipe.image} 
          alt={recipe.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <button 
          onClick={toggleFavorite}
          className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm p-1.5 rounded-full shadow-sm hover:scale-110 transition-transform z-10"
        >
          <Heart 
            size={16} 
            className={`transition-colors ${isFavorite ? 'text-red-500 fill-current' : 'text-gray-400 hover:text-red-500'}`} 
          />
        </button>
        
        {/* Hover Action Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <button className="bg-brand-500 text-white px-4 py-2 rounded-full font-bold flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-transform">
                <Play size={16} fill="currentColor" /> 详情
            </button>
        </div>

        <div className="absolute bottom-2 left-2 flex gap-2">
            {recipe.tags.slice(0, 2).map(tag => (
                <span key={tag} className="text-[10px] px-2 py-1 bg-black/60 text-white backdrop-blur-md rounded-full">
                    {tag}
                </span>
            ))}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-gray-800 dark:text-gray-100 mb-2 truncate">{recipe.title}</h3>
        
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-1">
            <Clock size={14} className="text-brand-400" />
            <span>{recipe.time} 分钟</span>
          </div>
          <div className="flex items-center gap-1">
            <Flame size={14} className="text-red-400" />
            <span>{recipe.calories} kcal</span>
          </div>
        </div>
        
        <div className="mt-3 flex items-center justify-between">
            <div className="flex text-yellow-400 text-xs">
                {'★'.repeat(Math.floor(recipe.rating))}
                <span className="text-gray-300 ml-1">({recipe.reviews})</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;