import React, { useEffect, useState, useRef } from 'react';
import { Terminal, Cpu, ChevronRight, CheckCircle2, AlertCircle, Search } from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: string;
  stage: 'PLANNING' | 'TOOL_CALL' | 'ANALYSIS' | 'DECISION';
  content: string;
  status: 'pending' | 'success' | 'error';
}

interface CoTConsoleProps {
  isVisible: boolean;
  triggerKey: number; // Used to restart animation
}

const CoTConsole: React.FC<CoTConsoleProps> = ({ isVisible, triggerKey }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isVisible || triggerKey === 0) return;

    setLogs([]);
    const mockSteps: Omit<LogEntry, 'id' | 'timestamp' | 'status'>[] = [
      { stage: 'PLANNING', content: 'Analyzing user intent: "Modify Lunch" detected.' },
      { stage: 'TOOL_CALL', content: 'SearchRecipe(tags=["high-carb", "noodle"], exclude=["peanuts"])' },
      { stage: 'ANALYSIS', content: 'Found 12 candidates. Filtering by User Profile (Allergies)...' },
      { stage: 'ANALYSIS', content: 'Calculating nutritional delta: Carbs +45g, Protein +12g' },
      { stage: 'DECISION', content: 'Selected "Classic Beef Noodles" (Score: 0.98)' },
    ];

    let delay = 0;
    mockSteps.forEach((step, index) => {
      delay += Math.random() * 800 + 400; // Random delay between steps
      setTimeout(() => {
        const newLog: LogEntry = {
          id: Math.random().toString(36),
          timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' }) + '.' + Math.floor(Math.random()*999),
          stage: step.stage,
          content: step.content,
          status: 'success'
        };
        setLogs(prev => [...prev, newLog]);
      }, delay);
    });

  }, [isVisible, triggerKey]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  if (!isVisible) return null;

  return (
    <div className="w-80 bg-gray-900 text-green-400 font-mono text-xs flex flex-col border-l border-gray-700 shadow-2xl animate-fade-in-right">
      {/* Header */}
      <div className="bg-gray-800 p-2 border-b border-gray-700 flex justify-between items-center text-gray-400">
        <div className="flex items-center gap-2">
          <Terminal size={14} />
          <span className="font-bold">AGENT_LOGS</span>
        </div>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20 border border-yellow-500"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500"></div>
        </div>
      </div>

      {/* Logs Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {logs.length === 0 && (
          <div className="text-gray-600 italic">Waiting for input stream...</div>
        )}
        
        {logs.map((log) => (
          <div key={log.id} className="animate-fade-in-up">
            <div className="flex items-center gap-2 mb-1 opacity-60">
              <span className="text-[10px] text-gray-500">[{log.timestamp}]</span>
              <span className={`text-[10px] font-bold px-1 rounded ${
                log.stage === 'TOOL_CALL' ? 'bg-blue-900 text-blue-300' :
                log.stage === 'DECISION' ? 'bg-purple-900 text-purple-300' :
                'bg-gray-700 text-gray-300'
              }`}>
                {log.stage}
              </span>
            </div>
            <div className="flex gap-2 items-start pl-2 border-l border-gray-700">
              <span className="mt-0.5">
                {log.stage === 'TOOL_CALL' ? <Search size={12} className="text-blue-400" /> : 
                 log.stage === 'DECISION' ? <CheckCircle2 size={12} className="text-green-400" /> :
                 <ChevronRight size={12} />}
              </span>
              <span className="leading-relaxed break-words text-gray-300">
                {log.content}
              </span>
            </div>
          </div>
        ))}
        
        {logs.length > 0 && logs.length < 5 && (
            <div className="flex items-center gap-2 text-gray-500 pl-2 animate-pulse">
                <span className="w-2 h-4 bg-green-500 block"></span>
                <span>Thinking...</span>
            </div>
        )}
      </div>

      {/* Footer Status */}
      <div className="bg-gray-800 p-2 border-t border-gray-700 flex justify-between items-center text-[10px] text-gray-500">
        <div className="flex items-center gap-1">
          <Cpu size={12} />
          <span>VRAM: 14.2GB</span>
        </div>
        <div>
          LATENCY: 45ms
        </div>
      </div>
    </div>
  );
};

export default CoTConsole;