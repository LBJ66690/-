import React from 'react';
import { X, ArrowRight, AlertTriangle, ArrowUpRight, Check } from 'lucide-react';

interface AttributionModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: {
    title: string;
    value: string;
    threshold: string;
  } | null;
}

const AttributionModal: React.FC<AttributionModalProps> = ({ isOpen, onClose, data }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity" onClick={onClose}></div>

      {/* Modal Content */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="bg-red-50 p-6 flex justify-between items-start border-b border-red-100">
          <div>
            <div className="flex items-center gap-2 text-red-600 mb-2">
              <AlertTriangle size={24} />
              <span className="font-bold text-lg tracking-tight">健康预警分析</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">{data?.title || '钠摄入超标警告'}</h2>
            <p className="text-red-500 mt-1 font-medium">当前值: <span className="text-3xl font-bold">{data?.value || '2600'}</span> mg <span className="text-sm text-gray-500 mx-2">vs</span> 阈值: {data?.threshold || '2000'} mg</p>
          </div>
          <button onClick={onClose} className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors">
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* 3-Column Analysis Body */}
        <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          
          {/* 1. The Cause */}
          <div className="relative group">
            <div className="absolute -top-3 left-0 bg-gray-100 text-gray-500 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">01. 溯源 (The Cause)</div>
            <div className="mt-4 p-4 rounded-xl border-2 border-dashed border-gray-200 bg-gray-50 hover:border-red-200 hover:bg-red-50/30 transition-all cursor-pointer">
              <img src="https://picsum.photos/id/292/300/200" className="w-full h-32 object-cover rounded-lg mb-3" alt="Cause" />
              <div className="font-bold text-gray-800">昨日晚餐: 红烧牛肉面</div>
              <div className="text-red-500 font-bold text-sm mt-1">含钠量: 1200mg</div>
              <div className="text-xs text-gray-500 mt-2">
                配料中的豆瓣酱和酱油是主要来源，且汤底未喝完。
              </div>
            </div>
            {/* Arrow */}
            <div className="hidden md:block absolute top-1/2 -right-6 -translate-y-1/2 text-gray-300">
               <ArrowRight size={24} />
            </div>
          </div>

          {/* 2. The Logic */}
          <div className="relative">
            <div className="absolute -top-3 left-0 bg-blue-100 text-blue-600 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">02. 归因逻辑 (Logic Chain)</div>
            <div className="mt-4 space-y-3">
               <div className="bg-white border border-gray-100 p-3 rounded-lg shadow-sm flex items-center justify-between">
                  <span className="text-sm text-gray-600">全天基础摄入</span>
                  <span className="font-bold text-gray-800">1400mg</span>
               </div>
               <div className="flex justify-center text-gray-300"><ArrowUpRight size={16} /></div>
               <div className="bg-red-50 border border-red-100 p-3 rounded-lg shadow-sm flex items-center justify-between">
                  <span className="text-sm text-red-800">晚餐额外增量</span>
                  <span className="font-bold text-red-600">+1200mg</span>
               </div>
               <div className="flex justify-center text-gray-300"><ArrowRight size={16} className="rotate-90" /></div>
               <div className="bg-gray-900 text-white p-3 rounded-lg shadow-md flex items-center justify-between">
                  <span className="text-sm">最终总和</span>
                  <span className="font-bold text-xl">2600mg</span>
               </div>
               <p className="text-xs text-center text-gray-400 mt-2">超过每日建议阈值 30%</p>
            </div>
             {/* Arrow */}
             <div className="hidden md:block absolute top-1/2 -right-6 -translate-y-1/2 text-gray-300">
               <ArrowRight size={24} />
            </div>
          </div>

          {/* 3. The Solution */}
          <div className="relative">
            <div className="absolute -top-3 left-0 bg-green-100 text-green-600 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">03. 补救方案 (Action)</div>
            <div className="mt-4 h-full flex flex-col">
              <div className="bg-green-50/50 p-5 rounded-xl border border-green-100 flex-1 flex flex-col items-center text-center">
                 <div className="bg-white p-3 rounded-full shadow-sm mb-3">
                    <span className="text-2xl">🍌</span>
                 </div>
                 <h4 className="font-bold text-gray-800 mb-2">建议补充高钾食物</h4>
                 <p className="text-sm text-gray-600 mb-6">钾离子有助于排出体内多余的钠。建议今日下午茶增加一根香蕉或一杯椰子水。</p>
                 
                 <button 
                    onClick={onClose}
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-green-200 transition-all flex items-center justify-center gap-2 group"
                 >
                    <Check size={18} />
                    一键添加到饮食记录
                 </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default AttributionModal;