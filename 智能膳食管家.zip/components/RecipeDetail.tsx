import React, { useState, useEffect } from 'react';
import { ChevronLeft, Play, Heart } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { MOCK_RECIPES } from '../constants';
import { toast } from 'sonner';

const RecipeDetail = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const recipe = MOCK_RECIPES.find(r => r.id === id);
    const [isFavorite, setIsFavorite] = useState(false);

    useEffect(() => {
        if (!recipe) return;
        const saved = localStorage.getItem('favorites');
        if (saved) {
            const ids = JSON.parse(saved);
            setIsFavorite(ids.includes(recipe.id));
        }
    }, [recipe]);

    const toggleFavorite = () => {
        if (!recipe) return;
        const saved = localStorage.getItem('favorites');
        let ids: string[] = saved ? JSON.parse(saved) : [];
        
        let newFavState = false;
        if (ids.includes(recipe.id)) {
            ids = ids.filter((savedId: string) => savedId !== recipe.id);
            toast.success("已取消收藏");
        } else {
            ids.push(recipe.id);
            newFavState = true;
            toast.success("已加入收藏夹");
        }
        
        localStorage.setItem('favorites', JSON.stringify(ids));
        setIsFavorite(newFavState);
    };

    if(!recipe) return <div>Not Found</div>;

    return (
        <div className="animate-fade-in pb-20">
            <button onClick={() => navigate(-1)} className="mb-4 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white flex items-center gap-1">
                <ChevronLeft size={20} /> 返回
            </button>
            
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
                <div className="h-80 relative">
                    <img src={recipe.image} className="w-full h-full object-cover" alt={recipe.title} />
                    <div className="absolute top-4 right-4 z-10">
                        <button 
                            onClick={toggleFavorite}
                            className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all text-white group"
                        >
                            <Heart 
                                size={24} 
                                className={`transition-colors ${isFavorite ? 'fill-red-500 text-red-500' : 'text-white group-hover:text-red-500'}`} 
                            />
                        </button>
                    </div>
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent p-8 text-white">
                        <div className="flex justify-between items-end">
                            <div>
                                <h1 className="text-4xl font-bold mb-2">{recipe.title}</h1>
                                <div className="flex items-center gap-4 text-sm opacity-90">
                                    <span className="bg-brand-500 px-2 py-0.5 rounded text-xs">AI 严选</span>
                                    <span>{recipe.rating} 分</span>
                                    <span>{recipe.reviews} 评论</span>
                                </div>
                            </div>
                            <button 
                                onClick={() => navigate(`/cooking/${recipe.id}`)}
                                className="bg-brand-500 hover:bg-brand-600 text-white px-8 py-3 rounded-full font-bold shadow-lg shadow-brand-500/40 flex items-center gap-2 transform hover:scale-105 transition-all"
                            >
                                <Play fill="currentColor" size={20} />
                                开始烹饪
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-10">
                    {/* Left: Info */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Ingredients */}
                        <section>
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 border-l-4 border-brand-500 pl-3">食材清单</h3>
                            <div className="grid grid-cols-2 gap-4">
                                {recipe.ingredients.map((ing, idx) => (
                                    <div key={idx} className="flex justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                                        <span className="text-gray-700 dark:text-gray-300">{ing.name}</span>
                                        <span className="font-bold text-gray-900 dark:text-white">{ing.amount}</span>
                                    </div>
                                ))}
                            </div>
                        </section>

                         {/* Steps */}
                         <section>
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 border-l-4 border-brand-500 pl-3">制作步骤</h3>
                            <div className="space-y-6">
                                {recipe.steps.map((step, idx) => (
                                    <div key={idx} className="flex gap-4 group">
                                        <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900/50 text-brand-600 dark:text-brand-400 flex items-center justify-center font-bold flex-shrink-0 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                                            {idx + 1}
                                        </div>
                                        <p className="text-gray-600 dark:text-gray-300 mt-2 text-lg leading-relaxed">{step}</p>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    {/* Right: Nutrition */}
                    <div className="space-y-6">
                        <div className="bg-gray-50 dark:bg-gray-700/30 p-6 rounded-2xl">
                            <h3 className="font-bold text-gray-800 dark:text-white mb-4">营养信息 (每份)</h3>
                            <div className="space-y-4">
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500 dark:text-gray-400">热量</span>
                                    <span className="font-bold text-brand-600 dark:text-brand-400 text-xl">{recipe.calories} kcal</span>
                                </div>
                                <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                                    <div className="h-full bg-brand-500 w-3/4"></div>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2">
                                    <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl">
                                        <div className="text-blue-500 font-bold text-lg">{recipe.protein}g</div>
                                        <div className="text-gray-400">蛋白</div>
                                    </div>
                                    <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-xl">
                                        <div className="text-yellow-500 font-bold text-lg">{recipe.fat}g</div>
                                        <div className="text-gray-400">脂肪</div>
                                    </div>
                                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-xl">
                                        <div className="text-green-500 font-bold text-lg">{recipe.carbs}g</div>
                                        <div className="text-gray-400">碳水</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RecipeDetail;