import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, X, Sparkles, SidebarOpen, SidebarClose, Mic, Camera } from 'lucide-react';
import { ChatMessage, Recipe } from '../types';
import { streamChatResponse } from '../services/aiService';
import { MOCK_RECIPES } from '../constants';
import PlanDiffCard from './PlanDiffCard';
import CoTConsole from './CoTConsole';
import { toast } from 'sonner';

interface ChatInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: '你好！我是您的智能膳食管家。您可以直接告诉我您的需求，比如“帮我推荐一道低卡晚餐”或“周三要游泳，帮我调整午餐”。',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showCoT, setShowCoT] = useState(false);
  const [cotTrigger, setCotTrigger] = useState(0); 

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen, showCoT]);

  const handleSend = async (forcedInput?: string) => {
    const textToSend = forcedInput || input;
    if (!textToSend.trim() || isTyping) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: textToSend,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    
    if (showCoT) setCotTrigger(prev => prev + 1);
    else {
        setShowCoT(true);
        setCotTrigger(prev => prev + 1);
    }

    const botMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: botMsgId,
      role: 'assistant',
      content: '...',
      timestamp: Date.now()
    }]);

    const isChangeScenario = textToSend.includes('游泳') || textToSend.includes('换') || textToSend.includes('牛肉面');
    const isFridgeScenario = textToSend.includes('清冰箱');

    await streamChatResponse(
      userMsg.content,
      (chunk) => {
        setMessages(prev => prev.map(m => 
          m.id === botMsgId ? { ...m, content: chunk } : m
        ));
      },
      (fullText, action) => {
        let finalAction = action;
        if (isChangeScenario) {
            finalAction = {
                type: 'UPDATE_PLAN',
                payload: {
                    date: '5/22 (周三)',
                    meal: '午餐',
                    oldRecipe: MOCK_RECIPES[1],
                    newRecipe: MOCK_RECIPES[3],
                    reason: '检测到您周三有高强度游泳计划，原食谱热量不足，建议增加碳水和蛋白质摄入。'
                }
            };
        } else if (isFridgeScenario) {
            finalAction = {
                type: 'UPDATE_PLAN',
                payload: {
                    date: '今日',
                    meal: '晚餐',
                    oldRecipe: MOCK_RECIPES[0],
                    newRecipe: MOCK_RECIPES[1], // 白玉菇炒火腿
                    reason: '已识别冰箱存有白玉菇和火腿，为您推荐这道快手菜，无需额外采购。'
                }
            };
        }

        setMessages(prev => prev.map(m => 
          m.id === botMsgId ? { ...m, content: fullText, action: finalAction } : m
        ));
        setIsTyping(false);
      }
    );
  };

  const handleMic = () => {
      toast("正在聆听...", { icon: <Mic className="animate-pulse" /> });
      setTimeout(() => {
          setInput("帮我用冰箱里的食材做道菜");
          toast.dismiss();
      }, 1500);
  }

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-end gap-2 animate-fade-in-up">
      <CoTConsole isVisible={showCoT} triggerKey={cotTrigger} />

      <div className="w-96 h-[600px] bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-gray-100 dark:border-gray-700">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 flex justify-between items-center text-white">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-white/20 rounded-full"><Bot size={20} /></div>
            <div>
              <h3 className="font-bold flex items-center gap-1">智谱 GLM-4 <Sparkles size={12} className="text-yellow-300" /></h3>
              <p className="text-xs text-blue-100 flex items-center gap-1"><span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span> Online</p>
            </div>
          </div>
          <div className="flex gap-1">
            <button onClick={() => setShowCoT(!showCoT)} className={`p-1.5 rounded transition-colors ${showCoT ? 'bg-white/20' : ''}`}><SidebarOpen size={18} /></button>
            <button onClick={onClose} className="hover:bg-white/20 p-1.5 rounded"><X size={18} /></button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 bg-gray-50 dark:bg-gray-900/50 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[95%] ${msg.action ? 'w-full' : ''}`}>
                 <div className={`p-3 rounded-2xl shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-blue-600 text-white rounded-tr-none ml-auto w-fit' 
                      : 'bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 border border-gray-100 dark:border-gray-600 rounded-tl-none w-fit'
                  }`}>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                 </div>
                
                {msg.action && msg.action.type === 'UPDATE_PLAN' && (
                  <PlanDiffCard 
                    oldRecipe={msg.action.payload.oldRecipe}
                    newRecipe={msg.action.payload.newRecipe}
                    date={msg.action.payload.date}
                    mealType={msg.action.payload.meal}
                    reason={msg.action.payload.reason}
                    onConfirm={() => {
                        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'system', content: '✅ 修改已生效', timestamp: Date.now() }]);
                        toast.success("食谱已更新！");
                    }}
                  />
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700">
           {/* Quick Actions */}
           <div className="flex gap-2 mb-3 overflow-x-auto pb-1 scrollbar-hide">
               <button onClick={() => handleSend("清冰箱")} className="whitespace-nowrap flex items-center gap-1 px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs text-gray-600 dark:text-gray-300 hover:bg-brand-50 hover:text-brand-600 transition-colors">
                  <Camera size={12} /> 清冰箱
               </button>
               <button onClick={() => handleSend("帮我生成今日采购清单")} className="whitespace-nowrap px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs text-gray-600 dark:text-gray-300 hover:bg-brand-50 hover:text-brand-600 transition-colors">
                  🛒 生成清单
               </button>
           </div>

          <div className="flex gap-2 items-center">
            <div className="flex-1 relative">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="输入您的健康需求..."
                    className="w-full pl-4 pr-10 py-2 bg-gray-100 dark:bg-gray-700 dark:text-white rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    disabled={isTyping}
                />
                <button 
                    onClick={handleMic}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-brand-500"
                >
                    <Mic size={16} />
                </button>
            </div>
            <button 
              onClick={() => handleSend()}
              disabled={isTyping || !input.trim()}
              className={`p-2 rounded-full transition-all ${
                input.trim() ? 'bg-blue-600 text-white shadow-md hover:bg-blue-700' : 'bg-gray-200 text-gray-400'
              }`}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;