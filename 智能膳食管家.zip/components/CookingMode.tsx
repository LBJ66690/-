import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Volume2, Maximize2, Minimize2, Mic, X, CheckCircle } from 'lucide-react';
import { MOCK_RECIPES } from '../constants';
import { toast } from 'sonner';

const CookingMode = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const recipe = MOCK_RECIPES.find(r => r.id === id);
  const [currentStep, setCurrentStep] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Mock Speech Recognition
  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
      toast.dismiss();
    } else {
      setIsListening(true);
      toast.info("语音控制已开启", {
        description: "试着说：'下一步' 或 '重复一遍'",
        duration: 5000,
        icon: <Mic className="animate-pulse text-brand-500" />
      });
      
      // Simulate voice command after 3 seconds for demo
      setTimeout(() => {
        if(Math.random() > 0.5) {
            handleNext();
            toast.success("识别指令: 下一步");
        }
        setIsListening(false);
      }, 3000);
    }
  };

  const speakStep = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'zh-CN';
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } else {
      toast.error("您的浏览器不支持语音播报");
    }
  };

  useEffect(() => {
    if (recipe) {
      speakStep(`第${currentStep + 1}步。${recipe.steps[currentStep]}`);
    }
    return () => window.speechSynthesis.cancel();
  }, [currentStep, recipe]);

  if (!recipe) return <div>Recipe not found</div>;

  const handleNext = () => {
    if (currentStep < recipe.steps.length - 1) setCurrentStep(c => c + 1);
    else toast.success("恭喜！烹饪完成！🎉");
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(c => c - 1);
  };

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col text-white animate-fade-in">
      {/* Top Bar */}
      <div className="flex justify-between items-center p-6 bg-black/20 backdrop-blur-md">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-white/10 rounded-full">
          <X size={28} />
        </button>
        <div className="flex flex-col items-center">
             <h2 className="text-xl font-bold">{recipe.title}</h2>
             <div className="text-sm text-gray-400">烹饪模式</div>
        </div>
        <div className="flex gap-4">
            <button 
                onClick={toggleListening}
                className={`p-3 rounded-full transition-all ${isListening ? 'bg-brand-600 animate-pulse' : 'bg-white/10 hover:bg-white/20'}`}
            >
                <Mic size={24} />
            </button>
            <button 
                onClick={() => speakStep(recipe.steps[currentStep])} 
                className={`p-3 rounded-full transition-all ${isSpeaking ? 'text-brand-400' : 'text-white hover:bg-white/10'}`}
            >
                <Volume2 size={24} />
            </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-8 relative overflow-hidden">
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gray-800">
            <div 
                className="h-full bg-brand-500 transition-all duration-500" 
                style={{ width: `${((currentStep + 1) / recipe.steps.length) * 100}%` }}
            ></div>
        </div>

        <div className="max-w-4xl w-full flex gap-10 items-center">
            {/* Large Step Number */}
            <div className="text-[12rem] font-black text-white/5 font-mono select-none absolute left-10 -z-10">
                {currentStep + 1}
            </div>

            <div className="flex-1 space-y-8 z-10">
                <div className="inline-block px-4 py-1 rounded-full bg-brand-500/20 text-brand-400 font-bold mb-4 border border-brand-500/30">
                    STEP {currentStep + 1} / {recipe.steps.length}
                </div>
                <h1 className="text-4xl md:text-6xl font-bold leading-tight tracking-tight">
                    {recipe.steps[currentStep]}
                </h1>
                
                {/* Timer suggestion if detected */}
                {recipe.steps[currentStep].match(/\d+分钟/) && (
                    <button className="flex items-center gap-2 bg-gray-800 border border-gray-700 hover:border-brand-500 px-6 py-3 rounded-xl transition-all">
                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                        <span className="font-mono text-xl">
                            {recipe.steps[currentStep].match(/(\d+)分钟/)?.[0]} 倒计时
                        </span>
                    </button>
                )}
            </div>

            {/* Ingredients Side Peek */}
            <div className="hidden lg:block w-80 bg-white/5 rounded-3xl p-6 border border-white/10 backdrop-blur-md">
                <h3 className="text-gray-400 text-sm font-bold uppercase tracking-wider mb-4">当前所需食材</h3>
                <ul className="space-y-3">
                    {recipe.ingredients.slice(0, 3).map((ing, i) => (
                        <li key={i} className="flex justify-between items-center text-lg">
                            <span>{ing.name}</span>
                            <span className="text-brand-400 font-mono">{ing.amount}</span>
                        </li>
                    ))}
                    {recipe.ingredients.length > 3 && <li className="text-gray-500 text-sm">...以及其他</li>}
                </ul>
            </div>
        </div>
      </div>

      {/* Controls */}
      <div className="h-32 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-center gap-8 pb-8">
        <button 
            onClick={handlePrev}
            disabled={currentStep === 0}
            className="w-16 h-16 rounded-full flex items-center justify-center bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
        >
            <ChevronLeft size={32} />
        </button>
        
        <div className="flex gap-2">
            {recipe.steps.map((_, i) => (
                <div 
                    key={i} 
                    className={`w-3 h-3 rounded-full transition-all ${i === currentStep ? 'bg-brand-500 scale-125' : 'bg-gray-600'}`}
                />
            ))}
        </div>

        <button 
            onClick={handleNext}
            className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                currentStep === recipe.steps.length - 1 
                ? 'bg-green-500 hover:bg-green-600 text-white shadow-lg shadow-green-500/40' 
                : 'bg-brand-500 hover:bg-brand-600 text-white shadow-lg shadow-brand-500/40'
            }`}
        >
            {currentStep === recipe.steps.length - 1 ? <CheckCircle size={32} /> : <ChevronRight size={32} />}
        </button>
      </div>
    </div>
  );
};

export default CookingMode;