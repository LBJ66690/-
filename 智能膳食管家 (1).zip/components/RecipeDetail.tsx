import React, { useState, useEffect } from 'react';
import { ChevronLeft, Play, Heart, Activity, Camera, X, MessageCircle } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { MOCK_RECIPES } from '../constants';
import { toast } from 'sonner';
import ReviewSection from './ReviewSection';
import NutritionModal from './NutritionModal';
import FoodGradeBadge from './FoodGradeBadge';

const RecipeDetail = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const recipe = MOCK_RECIPES.find(r => r.id === id);
    const [isFavorite, setIsFavorite] = useState(false);
    const [showNutrition, setShowNutrition] = useState(false);
    
    // Cooked It State
    const [showCookedModal, setShowCookedModal] = useState<string | null>(null);

    const cookedImages = [
        { id: 'c1', url: 'https://picsum.photos/id/111/200/200', user: 'Alice', comment: '第一次做，很成功！' },
        { id: 'c2', url: 'https://picsum.photos/id/112/200/200', user: 'Bob', comment: '有点咸了，下次少放盐。' },
        { id: 'c3', url: 'https://picsum.photos/id/113/200/200', user: 'Cat', comment: '孩子很爱吃。' },
        { id: 'c4', url: 'https://picsum.photos/id/114/200/200', user: 'Dog', comment: '卖相不错吧？' },
        { id: 'c5', url: 'https://picsum.photos/id/115/200/200', user: 'Egg', comment: '很简单。' },
    ];

    useEffect(() => {
        if (!recipe) return;
        const saved = localStorage.getItem('favorites');
        if (saved) {
            const ids = JSON.parse(saved);
            setIsFavorite(ids.includes(recipe.id));
        }
    }, [recipe]);

    const toggleFavorite = () => {
        if (!recipe) return;
        const saved = localStorage.getItem('favorites');
        let ids: string[] = saved ? JSON.parse(saved) : [];
        
        let newFavState = false;
        if (ids.includes(recipe.id)) {
            ids = ids.filter((savedId: string) => savedId !== recipe.id);
            toast.success("已取消收藏");
        } else {
            ids.push(recipe.id);
            newFavState = true;
            toast.success("已加入收藏夹");
        }
        
        localStorage.setItem('favorites', JSON.stringify(ids));
        setIsFavorite(newFavState);
    };

    const handleUploadCooked = () => {
        toast.promise(new Promise(resolve => setTimeout(resolve, 1500)), {
            loading: '正在上传...',
            success: '作业提交成功！积分 +10',
            error: '上传失败'
        });
    };

    if(!recipe) return <div>Not Found</div>;

    return (
        <div className="animate-fade-in pb-20">
            <button onClick={() => navigate(-1)} className="mb-4 text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white flex items-center gap-1">
                <ChevronLeft size={20} /> 返回
            </button>
            
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
                <div className="h-80 relative">
                    <img src={recipe.image} className="w-full h-full object-cover" alt={recipe.title} />
                    <div className="absolute top-4 right-4 z-10">
                        <button 
                            onClick={toggleFavorite}
                            className="bg-white/20 backdrop-blur-md p-3 rounded-full hover:bg-white/30 transition-all text-white group"
                        >
                            <Heart 
                                size={24} 
                                className={`transition-colors ${isFavorite ? 'fill-red-500 text-red-500' : 'text-white group-hover:text-red-500'}`} 
                            />
                        </button>
                    </div>
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent p-8 text-white">
                        <div className="flex justify-between items-end">
                            <div>
                                <h1 className="text-4xl font-bold mb-2">{recipe.title}</h1>
                                <div className="flex items-center gap-4 text-sm opacity-90">
                                    <span className="bg-brand-500 px-2 py-0.5 rounded text-xs">AI 严选</span>
                                    <span>{recipe.rating} 分</span>
                                    <span>{recipe.reviews} 评论</span>
                                    <FoodGradeBadge calories={recipe.calories} fat={recipe.fat} className="bg-white/20 border-transparent text-white backdrop-blur-md" />
                                </div>
                            </div>
                            <button 
                                onClick={() => navigate(`/cooking/${recipe.id}`)}
                                className="bg-brand-500 hover:bg-brand-600 text-white px-8 py-3 rounded-full font-bold shadow-lg shadow-brand-500/40 flex items-center gap-2 transform hover:scale-105 transition-all"
                            >
                                <Play fill="currentColor" size={20} />
                                开始烹饪
                            </button>
                        </div>
                    </div>
                </div>

                <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-10">
                    {/* Left: Info */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Ingredients */}
                        <section>
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 border-l-4 border-brand-500 pl-3">食材清单</h3>
                            <div className="grid grid-cols-2 gap-4">
                                {recipe.ingredients.map((ing, idx) => (
                                    <div key={idx} className="flex justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                                        <span className="text-gray-700 dark:text-gray-300">{ing.name}</span>
                                        <span className="font-bold text-gray-900 dark:text-white">{ing.amount}</span>
                                    </div>
                                ))}
                            </div>
                        </section>

                         {/* Steps */}
                         <section>
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 border-l-4 border-brand-500 pl-3">制作步骤</h3>
                            <div className="space-y-6">
                                {recipe.steps.map((step, idx) => (
                                    <div key={idx} className="flex gap-4 group">
                                        <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900/50 text-brand-600 dark:text-brand-400 flex items-center justify-center font-bold flex-shrink-0 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                                            {idx + 1}
                                        </div>
                                        <p className="text-gray-600 dark:text-gray-300 mt-2 text-lg leading-relaxed">{step}</p>
                                    </div>
                                ))}
                            </div>
                        </section>

                        {/* Cooked It Section (New) */}
                        <section className="bg-gray-50 dark:bg-gray-700/30 p-6 rounded-2xl">
                             <div className="flex items-center justify-between mb-4">
                                 <h3 className="text-lg font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                     <Camera className="text-brand-500" size={20} />
                                     大家都在做 <span className="text-gray-400 text-sm font-normal">128 人交了作业</span>
                                 </h3>
                                 <button className="text-sm text-brand-600 dark:text-brand-400 font-bold hover:underline">查看全部</button>
                             </div>
                             
                             <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
                                 {/* Upload Button */}
                                 <button 
                                    onClick={handleUploadCooked}
                                    className="min-w-[100px] h-[100px] rounded-xl border-2 border-dashed border-brand-300 bg-brand-50 dark:bg-brand-900/10 dark:border-brand-700 flex flex-col items-center justify-center text-brand-500 gap-1 hover:bg-brand-100 dark:hover:bg-brand-900/30 transition-colors"
                                 >
                                     <Camera size={24} />
                                     <span className="text-xs font-bold">交作业</span>
                                 </button>
                                 
                                 {/* Gallery */}
                                 {cookedImages.map(img => (
                                     <div 
                                        key={img.id}
                                        onClick={() => setShowCookedModal(img.id)} 
                                        className="relative min-w-[100px] h-[100px] rounded-xl overflow-hidden cursor-pointer group"
                                     >
                                         <img src={img.url} className="w-full h-full object-cover transition-transform group-hover:scale-110" alt="cooked" />
                                         <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                                     </div>
                                 ))}
                             </div>
                        </section>

                        {/* Reviews */}
                        <ReviewSection />
                    </div>

                    {/* Right: Nutrition */}
                    <div className="space-y-6">
                        <div className="bg-gray-50 dark:bg-gray-700/30 p-6 rounded-2xl relative overflow-hidden">
                            <h3 className="font-bold text-gray-800 dark:text-white mb-4 z-10 relative flex justify-between items-center">
                                营养信息 (每份)
                            </h3>
                            <div className="space-y-4 z-10 relative">
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500 dark:text-gray-400">热量</span>
                                    <span className="font-bold text-brand-600 dark:text-brand-400 text-xl">{recipe.calories} kcal</span>
                                </div>
                                <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                                    <div className="h-full bg-brand-500 w-3/4"></div>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2">
                                    <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl">
                                        <div className="text-blue-500 font-bold text-lg">{recipe.protein}g</div>
                                        <div className="text-gray-400">蛋白</div>
                                    </div>
                                    <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-xl">
                                        <div className="text-yellow-500 font-bold text-lg">{recipe.fat}g</div>
                                        <div className="text-gray-400">脂肪</div>
                                    </div>
                                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-xl">
                                        <div className="text-green-500 font-bold text-lg">{recipe.carbs}g</div>
                                        <div className="text-gray-400">碳水</div>
                                    </div>
                                </div>
                            </div>
                            
                            <button 
                                onClick={() => setShowNutrition(true)}
                                className="w-full mt-6 bg-white dark:bg-gray-800 border border-brand-200 text-brand-600 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-brand-50 transition-colors"
                            >
                                <Activity size={16} /> 查看详细微量元素
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Cooked Detail Modal */}
            {showCookedModal && (
                <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowCookedModal(null)}></div>
                    <div className="relative bg-white dark:bg-gray-800 rounded-2xl overflow-hidden max-w-2xl w-full flex flex-col md:flex-row animate-scale-in">
                        <button onClick={() => setShowCookedModal(null)} className="absolute top-4 right-4 text-white z-10 bg-black/20 rounded-full p-1"><X size={20} /></button>
                        <div className="w-full md:w-1/2 bg-black flex items-center justify-center">
                            <img src={cookedImages.find(c => c.id === showCookedModal)?.url} className="w-full h-full object-cover" alt="Detail" />
                        </div>
                        <div className="p-6 md:w-1/2 flex flex-col">
                            <div className="flex items-center gap-3 mb-4">
                                <img src="https://picsum.photos/id/64/50/50" className="w-10 h-10 rounded-full" alt="User" />
                                <div>
                                    <div className="font-bold dark:text-white">{cookedImages.find(c => c.id === showCookedModal)?.user}</div>
                                    <div className="text-xs text-gray-500">2小时前</div>
                                </div>
                            </div>
                            <p className="text-gray-600 dark:text-gray-300 flex-1">
                                "{cookedImages.find(c => c.id === showCookedModal)?.comment}"
                            </p>
                            
                            <div className="mt-6 bg-brand-50 dark:bg-brand-900/20 p-4 rounded-xl">
                                <div className="flex items-center gap-2 mb-2 text-brand-600 font-bold text-sm">
                                    <MessageCircle size={16} /> AI 点评
                                </div>
                                <p className="text-xs text-brand-800 dark:text-brand-300 leading-relaxed">
                                    卖相非常有食欲！色彩搭配均衡，火候掌握得当。建议下次可以尝试撒一点欧芹碎作为装饰，视觉效果会更上一层楼。
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <NutritionModal 
                isOpen={showNutrition} 
                onClose={() => setShowNutrition(false)}
                data={{
                    calories: recipe.calories,
                    protein: recipe.protein,
                    fat: recipe.fat,
                    carbs: recipe.carbs
                }}
            />
        </div>
    );
};

export default RecipeDetail;