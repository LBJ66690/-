import React, { useState, useEffect } from 'react';
import { Save, User, Activity, Utensils, X, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { MOCK_USER } from '../constants';

const Settings = () => {
  const [formData, setFormData] = useState({
    name: MOCK_USER.name,
    gender: 'male',
    height: MOCK_USER.height,
    weight: MOCK_USER.weight,
    age: 28,
    pal: 1.375, // Activity Level
    allergies: [...MOCK_USER.allergies],
    preferences: ['辣味', '海鲜']
  });

  const [newTag, setNewTag] = useState('');
  const [bmr, setBmr] = useState(0);
  const [tdee, setTdee] = useState(0);

  // Calculate BMR & TDEE automatically
  useEffect(() => {
    // Mifflin-St Jeor Equation
    let baseBMR = (10 * formData.weight) + (6.25 * formData.height) - (5 * formData.age);
    if (formData.gender === 'male') baseBMR += 5;
    else baseBMR -= 161;

    setBmr(Math.round(baseBMR));
    setTdee(Math.round(baseBMR * formData.pal));
  }, [formData.weight, formData.height, formData.age, formData.gender, formData.pal]);

  const handleSave = () => {
    toast.promise(new Promise(resolve => setTimeout(resolve, 1000)), {
        loading: '正在同步健康档案...',
        success: '保存成功！已更新您的代谢模型。',
        error: '保存失败'
    });
  };

  const addTag = (type: 'allergies' | 'preferences') => {
    if(!newTag.trim()) return;
    if(formData[type].includes(newTag)) {
        toast.error('标签已存在');
        return;
    }
    setFormData(prev => ({
        ...prev,
        [type]: [...prev[type], newTag]
    }));
    setNewTag('');
  };

  const removeTag = (type: 'allergies' | 'preferences', tag: string) => {
    setFormData(prev => ({
        ...prev,
        [type]: prev[type].filter(t => t !== tag)
    }));
  };

  return (
    <div className="max-w-4xl mx-auto pb-24 animate-fade-in">
      <div className="flex items-center gap-3 mb-8">
         <div className="bg-gray-900 text-white p-3 rounded-2xl">
             <User size={24} />
         </div>
         <h1 className="text-2xl font-bold text-gray-900 dark:text-white">个人档案设置</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Form */}
        <div className="lg:col-span-2 space-y-6">
            
            {/* Basic Info */}
            <section className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 className="font-bold text-gray-800 dark:text-white mb-4">基础信息</h3>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs text-gray-500 mb-1">昵称</label>
                        <input 
                            type="text" 
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="w-full bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none dark:text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-xs text-gray-500 mb-1">性别</label>
                        <select 
                            value={formData.gender}
                            onChange={e => setFormData({...formData, gender: e.target.value})}
                            className="w-full bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none dark:text-white"
                        >
                            <option value="male">男</option>
                            <option value="female">女</option>
                        </select>
                    </div>
                </div>
            </section>

            {/* Body Stats */}
            <section className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 className="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                    <Activity size={18} className="text-brand-500" /> 身体数据
                </h3>
                <div className="grid grid-cols-3 gap-4 mb-4">
                    <div>
                        <label className="block text-xs text-gray-500 mb-1">身高 (cm)</label>
                        <input 
                            type="number" 
                            value={formData.height}
                            onChange={e => setFormData({...formData, height: Number(e.target.value)})}
                            className="w-full bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 font-mono text-sm dark:text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-xs text-gray-500 mb-1">体重 (kg)</label>
                        <input 
                            type="number" 
                            value={formData.weight}
                            onChange={e => setFormData({...formData, weight: Number(e.target.value)})}
                            className="w-full bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 font-mono text-sm dark:text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-xs text-gray-500 mb-1">年龄</label>
                        <input 
                            type="number" 
                            value={formData.age}
                            onChange={e => setFormData({...formData, age: Number(e.target.value)})}
                            className="w-full bg-gray-50 dark:bg-gray-700 rounded-lg px-4 py-2 font-mono text-sm dark:text-white"
                        />
                    </div>
                </div>
                <div>
                     <label className="block text-xs text-gray-500 mb-2">日常活动强度</label>
                     <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                         {[
                             { label: '久坐不动', val: 1.2 },
                             { label: '轻度运动', val: 1.375 },
                             { label: '中度运动', val: 1.55 },
                             { label: '重体力', val: 1.725 },
                         ].map(opt => (
                             <button
                                key={opt.val}
                                onClick={() => setFormData({...formData, pal: opt.val})}
                                className={`text-xs py-2 rounded-lg border transition-all ${
                                    formData.pal === opt.val 
                                    ? 'bg-brand-500 text-white border-brand-500' 
                                    : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300 border-gray-200 dark:border-gray-600 hover:border-brand-300'
                                }`}
                             >
                                 {opt.label}
                             </button>
                         ))}
                     </div>
                </div>
            </section>

            {/* Preferences */}
            <section className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 className="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                    <Utensils size={18} className="text-green-500" /> 饮食偏好
                </h3>
                
                <div className="mb-6">
                    <label className="block text-xs text-red-500 font-bold mb-2">🚫 忌口/过敏 (Blacklist)</label>
                    <div className="flex flex-wrap gap-2 mb-2">
                        {formData.allergies.map(tag => (
                            <span key={tag} className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                                {tag}
                                <button onClick={() => removeTag('allergies', tag)}><X size={14} /></button>
                            </span>
                        ))}
                        <div className="flex items-center gap-2">
                             <input 
                                type="text" 
                                placeholder="添加..." 
                                className="bg-gray-50 dark:bg-gray-700 rounded-full px-3 py-1 text-sm w-24 focus:outline-none dark:text-white"
                                value={newTag}
                                onChange={e => setNewTag(e.target.value)}
                                onKeyDown={e => { if(e.key === 'Enter') addTag('allergies'); }}
                             />
                             <button onClick={() => addTag('allergies')} className="bg-gray-200 dark:bg-gray-600 rounded-full p-1"><Plus size={14} /></button>
                        </div>
                    </div>
                </div>

                <div>
                    <label className="block text-xs text-green-600 font-bold mb-2">💚 喜好 (Whitelist)</label>
                    <div className="flex flex-wrap gap-2">
                        {formData.preferences.map(tag => (
                            <span key={tag} className="bg-green-50 text-green-600 px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                                {tag}
                                <button onClick={() => removeTag('preferences', tag)}><X size={14} /></button>
                            </span>
                        ))}
                    </div>
                </div>
            </section>
        </div>

        {/* Right Column: Calculations */}
        <div className="space-y-6">
             <div className="sticky top-24 space-y-6">
                <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
                    <div className="relative z-10">
                        <h4 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-4">代谢模型预览</h4>
                        
                        <div className="flex justify-between items-end mb-4 border-b border-white/10 pb-4">
                            <div>
                                <div className="text-sm text-gray-400">基础代谢 (BMR)</div>
                                <div className="text-3xl font-bold font-mono text-blue-400">{bmr}</div>
                            </div>
                            <div className="text-xs text-gray-500">kcal/day</div>
                        </div>

                        <div className="flex justify-between items-end">
                            <div>
                                <div className="text-sm text-gray-400">每日总消耗 (TDEE)</div>
                                <div className="text-3xl font-bold font-mono text-green-400">{tdee}</div>
                            </div>
                            <div className="text-xs text-gray-500">kcal/day</div>
                        </div>
                        
                        <div className="mt-6 text-xs text-gray-500 bg-black/20 p-2 rounded">
                            * 此数据将用于 AI 生成食谱的热量基准。
                        </div>
                    </div>
                    {/* Background decorations */}
                    <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500 rounded-full blur-[60px] opacity-20"></div>
                </div>
             </div>
        </div>

      </div>

      {/* Floating Save Button */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white px-8 py-3 rounded-full shadow-xl shadow-brand-500/40 font-bold text-lg transition-all transform hover:scale-105"
          >
              <Save size={20} /> 保存修改
          </button>
      </div>
    </div>
  );
};

export default Settings;