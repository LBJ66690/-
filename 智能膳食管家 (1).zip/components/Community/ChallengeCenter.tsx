import React from 'react';
import { Trophy, Flame, Users, ArrowRight, Medal, Target } from 'lucide-react';
import { toast } from 'sonner';

const ChallengeCenter = () => {
  const activeChallenge = {
    title: '21天控糖战役',
    daysTotal: 21,
    daysDone: 5,
    participants: 1203,
    description: '拒绝游离糖，重塑味蕾敏感度。'
  };

  const challenges = [
    { id: 1, title: '7天早餐不重样', participants: 850, icon: '🍳', color: 'bg-orange-100 text-orange-600' },
    { id: 2, title: '每天喝水 2.5L', participants: 2100, icon: '💧', color: 'bg-blue-100 text-blue-600' },
    { id: 3, title: '零食戒断计划', participants: 530, icon: '🚫', color: 'bg-red-100 text-red-600' },
  ];

  const leaderboard = [
    { rank: 1, name: 'FitAlice', score: 2450, avatar: 'https://picsum.photos/id/10/50/50' },
    { rank: 2, name: 'MuscleBob', score: 2380, avatar: 'https://picsum.photos/id/12/50/50' },
    { rank: 3, name: 'HealthyJo', score: 2100, avatar: 'https://picsum.photos/id/15/50/50' },
    { rank: 4, name: 'RunForest', score: 1950, avatar: 'https://picsum.photos/id/22/50/50' },
    { rank: 5, name: 'YogaGirl', score: 1800, avatar: 'https://picsum.photos/id/33/50/50' },
    { rank: 6, name: 'IronMan', score: 1750, avatar: 'https://picsum.photos/id/44/50/50' },
  ];

  return (
    <div className="pb-24 animate-fade-in space-y-8">
      
      {/* Header Banner */}
      <div className="relative bg-gradient-to-r from-violet-600 to-indigo-600 rounded-3xl p-8 text-white overflow-hidden shadow-xl mx-4 lg:mx-0">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
             <span className="bg-white/20 px-2 py-0.5 rounded text-xs font-bold backdrop-blur-sm">🔥 热门挑战</span>
             <span className="text-xs text-indigo-100 flex items-center gap-1"><Users size={12} /> {activeChallenge.participants} 人参与</span>
          </div>
          <h1 className="text-3xl font-bold mb-2">{activeChallenge.title}</h1>
          <p className="text-indigo-100 mb-6 max-w-xs">{activeChallenge.description}</p>
          <button 
            onClick={() => toast.success('已加入挑战！')}
            className="bg-white text-indigo-600 px-6 py-2 rounded-full font-bold shadow-lg hover:bg-indigo-50 transition-colors"
          >
            立即加入
          </button>
        </div>
        {/* Background Decor */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 right-10 text-9xl opacity-20 rotate-12 select-none">🏆</div>
      </div>

      {/* My Progress */}
      <div className="px-4 lg:px-0">
         <h2 className="font-bold text-xl text-gray-800 dark:text-white mb-4 flex items-center gap-2">
             <Target className="text-brand-500" /> 我的挑战
         </h2>
         <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
             <div className="flex justify-between items-center mb-3">
                 <h3 className="font-bold text-gray-800 dark:text-white">{activeChallenge.title}</h3>
                 <span className="text-brand-500 font-bold text-sm">{activeChallenge.daysDone}/{activeChallenge.daysTotal} 天</span>
             </div>
             <div className="w-full bg-gray-100 dark:bg-gray-700 h-3 rounded-full overflow-hidden mb-2">
                 <div className="h-full bg-brand-500 rounded-full transition-all duration-1000" style={{width: `${(activeChallenge.daysDone / activeChallenge.daysTotal) * 100}%`}}></div>
             </div>
             <p className="text-xs text-gray-500 dark:text-gray-400">已连续坚持 {activeChallenge.daysDone} 天，继续保持！</p>
         </div>
      </div>

      {/* Challenge List */}
      <div className="px-4 lg:px-0">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-bold text-xl text-gray-800 dark:text-white">探索更多</h2>
            <button className="text-xs text-gray-500 flex items-center gap-1">全部 <ArrowRight size={12} /></button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {challenges.map(c => (
                  <div key={c.id} className="bg-white dark:bg-gray-800 p-4 rounded-2xl border border-gray-100 dark:border-gray-700 flex items-center gap-4 hover:shadow-md transition-shadow cursor-pointer">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${c.color}`}>
                          {c.icon}
                      </div>
                      <div>
                          <h4 className="font-bold text-gray-800 dark:text-white text-sm">{c.title}</h4>
                          <p className="text-xs text-gray-500 mt-1">{c.participants} 人在挑战</p>
                      </div>
                  </div>
              ))}
          </div>
      </div>

      {/* Leaderboard */}
      <div className="px-4 lg:px-0">
          <h2 className="font-bold text-xl text-gray-800 dark:text-white mb-4 flex items-center gap-2">
              <Trophy className="text-yellow-500" /> 今日自律榜
          </h2>
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
              {leaderboard.map((user, index) => (
                  <div key={user.rank} className="flex items-center p-4 border-b border-gray-50 dark:border-gray-700 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      <div className="w-8 text-center font-bold text-gray-400 mr-2">
                          {index === 0 && <span className="text-2xl">🥇</span>}
                          {index === 1 && <span className="text-2xl">🥈</span>}
                          {index === 2 && <span className="text-2xl">🥉</span>}
                          {index > 2 && user.rank}
                      </div>
                      <img src={user.avatar} className="w-10 h-10 rounded-full border border-gray-200 dark:border-gray-600 mr-3" alt={user.name} />
                      <div className="flex-1">
                          <div className="font-bold text-gray-800 dark:text-white text-sm">{user.name}</div>
                          <div className="text-xs text-gray-500">坚持打卡 {Math.floor(Math.random() * 300)} 天</div>
                      </div>
                      <div className="font-mono font-bold text-brand-600 dark:text-brand-400">
                          {user.score} <span className="text-xs text-gray-400 font-normal">kcal</span>
                      </div>
                  </div>
              ))}
              
              {/* My Rank Footer */}
              <div className="bg-brand-50 dark:bg-brand-900/20 p-4 flex items-center border-t border-brand-100 dark:border-brand-900">
                  <div className="w-8 text-center font-bold text-brand-600 mr-2">12</div>
                  <img src="https://picsum.photos/id/64/50/50" className="w-10 h-10 rounded-full border-2 border-white mr-3" alt="Me" />
                  <div className="flex-1">
                      <div className="font-bold text-brand-900 dark:text-brand-100 text-sm">我</div>
                  </div>
                  <div className="font-mono font-bold text-brand-600 dark:text-brand-400">
                      1250 <span className="text-xs font-normal">kcal</span>
                  </div>
              </div>
          </div>
      </div>

    </div>
  );
};

export default ChallengeCenter;