import React from 'react';
import { X, Info, Activity } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface NutritionModalProps {
  isOpen: boolean;
  onClose: () => void;
  // If null, show mock/default data
  data?: {
    calories: number;
    protein: number;
    fat: number;
    carbs: number;
  };
}

const NutritionModal: React.FC<NutritionModalProps> = ({ isOpen, onClose, data }) => {
  if (!isOpen) return null;

  const stats = data || { calories: 650, protein: 35, fat: 25, carbs: 70 };
  const chartData = [
    { name: '蛋白质', value: stats.protein, color: '#3b82f6' },
    { name: '脂肪', value: stats.fat, color: '#fbbf24' },
    { name: '碳水', value: stats.carbs, color: '#10b981' },
  ];

  const micros = [
    { name: '钠 (Sodium)', value: '1200mg', limit: '2000mg', status: 'high' },
    { name: '钾 (Potassium)', value: '450mg', limit: '3500mg', status: 'low' },
    { name: '胆固醇', value: '150mg', limit: '300mg', status: 'ok' },
    { name: '膳食纤维', value: '4g', limit: '25g', status: 'low' },
    { name: '维生素C', value: '12mg', limit: '100mg', status: 'low' },
  ];

  const getStatusColor = (status: string) => {
    switch(status) {
        case 'high': return 'bg-red-500';
        case 'ok': return 'bg-green-500';
        case 'low': return 'bg-yellow-500';
        default: return 'bg-gray-300';
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative bg-white dark:bg-gray-900 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-fade-in-up border border-white/10">
        
        {/* Header */}
        <div className="bg-gray-900 text-white p-6 flex justify-between items-center">
            <div className="flex items-center gap-3">
                <div className="bg-brand-500 p-2 rounded-lg"><Activity size={20} /></div>
                <div>
                    <h2 className="text-xl font-bold">营养深度分析</h2>
                    <p className="text-xs text-gray-400">基于 USDA 标准数据库 V14</p>
                </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X size={24} />
            </button>
        </div>

        <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Macros Chart */}
            <div className="flex flex-col items-center justify-center relative">
                <h3 className="text-gray-500 font-bold mb-4 text-sm uppercase tracking-wider">宏量营养素供能比</h3>
                <div className="w-48 h-48 relative">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={chartData}
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                                stroke="none"
                            >
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                    {/* Center Text */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-3xl font-bold text-gray-800 dark:text-white">{stats.calories}</span>
                        <span className="text-xs text-gray-400">kcal</span>
                    </div>
                </div>

                <div className="flex gap-4 mt-6">
                    {chartData.map(item => (
                        <div key={item.name} className="flex items-center gap-1.5">
                            <div className="w-3 h-3 rounded-full" style={{backgroundColor: item.color}}></div>
                            <div className="text-xs text-gray-600 dark:text-gray-300">
                                <span className="font-bold">{item.name}</span> {item.value}g
                            </div>
                        </div>
                    ))}
                </div>
                
                <div className="mt-6 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl text-xs text-gray-500 leading-relaxed flex gap-2">
                    <Info size={16} className="shrink-0 text-brand-500" />
                    该食谱碳水占比略高，建议搭配一份水煮青菜以平衡血糖反应。
                </div>
            </div>

            {/* Micros List */}
            <div>
                <h3 className="text-gray-500 font-bold mb-4 text-sm uppercase tracking-wider flex justify-between">
                    <span>微量元素监控</span>
                    <span className="text-[10px] bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded">每 100g 含量</span>
                </h3>
                
                <div className="space-y-4">
                    {micros.map((micro, idx) => (
                        <div key={idx} className="flex items-center justify-between group">
                            <div className="flex items-center gap-3">
                                <div className={`w-2 h-2 rounded-full ${getStatusColor(micro.status)} shadow-sm`}></div>
                                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{micro.name}</span>
                            </div>
                            <div className="flex items-center gap-3">
                                <span className="text-sm font-bold text-gray-900 dark:text-white">{micro.value}</span>
                                <div className="w-20 h-1.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full rounded-full ${getStatusColor(micro.status)}`} 
                                        style={{width: '60%'}} // Simulated percentage
                                    ></div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-8 border-t border-gray-100 dark:border-gray-700 pt-4">
                    <h4 className="font-bold text-sm text-gray-800 dark:text-white mb-2">对比您的每日额度</h4>
                    <div className="space-y-2">
                         <div className="flex justify-between text-xs text-gray-500">
                             <span>热量消耗</span>
                             <span>35%</span>
                         </div>
                         <div className="w-full bg-gray-100 dark:bg-gray-700 h-2 rounded-full overflow-hidden">
                             <div className="bg-brand-500 h-full w-[35%]"></div>
                         </div>
                         <p className="text-[10px] text-gray-400 mt-1">此食谱约占您全天 TDEE 的 35%，适合作为午餐。</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default NutritionModal;