import React, { useState } from 'react';
import { 
    ChevronLeft, ChevronRight, Sparkles, Droplets, Flame, Utensils, 
    Calendar, Plus, ShoppingBag, PieChart as PieChartIcon, Copy, CreditCard
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { MOCK_RECIPES } from '../constants';
import { Recipe } from '../types';
import { toast } from 'sonner';

const MealPlan = () => {
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const [currentWeek, setCurrentWeek] = useState('2024.05.20 - 2024.05.26');
  
  // State for drag and drop simulation
  // Map key format: "dayIndex-mealId" -> Recipe
  const [mealMap, setMealMap] = useState<Record<string, Recipe>>(() => {
      const initial: Record<string, Recipe> = {};
      days.forEach((_, dIdx) => {
          ['breakfast', 'lunch', 'dinner'].forEach((mType) => {
             const seed = dIdx + mType.length;
             initial[`${dIdx}-${mType}`] = MOCK_RECIPES[seed % MOCK_RECIPES.length];
          });
      });
      return initial;
  });

  const [draggedRecipe, setDraggedRecipe] = useState<Recipe | null>(null);

  const handleDragStart = (e: React.DragEvent, recipe: Recipe) => {
      setDraggedRecipe(recipe);
      e.dataTransfer.effectAllowed = 'move';
  };

  const handleDrop = (e: React.DragEvent, dayIdx: number, mealId: string) => {
      e.preventDefault();
      if (draggedRecipe) {
          const key = `${dayIdx}-${mealId}`;
          setMealMap(prev => ({
              ...prev,
              [key]: draggedRecipe
          }));
          toast.success(`已更新 ${days[dayIdx]} 的 ${mealId === 'breakfast' ? '早餐' : mealId === 'lunch' ? '午餐' : '晚餐'}`, {
              icon: <Sparkles size={16} className="text-brand-500" />
          });
          setDraggedRecipe(null);
      }
  };

  const meals = [
      { id: 'breakfast', name: '早餐', icon: <Droplets size={16} className="text-blue-400" /> }, 
      { id: 'lunch', name: '午餐', icon: <Flame size={16} className="text-orange-400" /> }, 
      { id: 'dinner', name: '晚餐', icon: <Utensils size={16} className="text-indigo-400" /> }
  ];

  const handleCopyList = () => {
      navigator.clipboard.writeText("1. 鸡胸肉 500g\n2. 西兰花 2颗\n3. 全麦面包 1袋");
      toast.success("购物清单已复制到剪贴板");
  };

  const handleBuy = () => {
      toast.promise(new Promise(resolve => setTimeout(resolve, 2000)), {
          loading: '正在连接生鲜电商平台...',
          success: '已生成订单，预估金额 ¥128.5',
          error: '连接失败'
      });
  };

  return (
      <div className="h-full flex flex-col gap-6 animate-fade-in pb-20">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-center bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-4 mb-4 md:mb-0">
                  <div className="bg-brand-50 dark:bg-brand-900/20 p-2 rounded-lg">
                      <Calendar className="text-brand-500" size={24} />
                  </div>
                  <div>
                      <h1 className="text-xl font-bold text-gray-800 dark:text-white">本周膳食计划</h1>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{currentWeek}</p>
                  </div>
              </div>
              <div className="flex gap-2 items-center">
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg dark:text-gray-300"><ChevronLeft size={20} /></button>
                  <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm font-bold text-gray-700 dark:text-gray-200">本周</button>
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg dark:text-gray-300"><ChevronRight size={20} /></button>
                  <div className="h-6 w-px bg-gray-200 dark:bg-gray-600 mx-2"></div>
                  <button className="hidden md:flex items-center gap-2 bg-brand-500 text-white px-4 py-2 rounded-lg font-bold shadow hover:bg-brand-600 transition-colors">
                      <Sparkles size={16} />
                      AI 重新生成
                  </button>
              </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[600px]">
              {/* Calendar Grid with Drag and Drop */}
              <div className="flex-1 bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4 overflow-x-auto border border-gray-100 dark:border-gray-700">
                  <div className="min-w-[800px] h-full flex flex-col">
                      {/* Days Header */}
                      <div className="grid grid-cols-8 gap-4 mb-4 pb-2 border-b border-gray-100 dark:border-gray-700">
                          <div className="font-bold text-gray-400 text-sm flex items-end">时段</div>
                          {days.map((day, i) => (
                              <div key={day} className="text-center">
                                  <div className="text-xs text-gray-400">5/{20+i}</div>
                                  <div className={`font-bold ${i===2 ? 'text-brand-500' : 'text-gray-700 dark:text-gray-300'}`}>{day}</div>
                              </div>
                          ))}
                      </div>

                      {/* Meal Rows */}
                      <div className="flex-1 space-y-4">
                          {meals.map((meal) => (
                              <div key={meal.id} className="grid grid-cols-8 gap-4 min-h-[140px]">
                                  {/* Row Label */}
                                  <div className="flex flex-col justify-center items-center gap-2 text-gray-500 bg-gray-50/50 dark:bg-gray-700/30 rounded-xl">
                                      {meal.icon}
                                      <span className="text-sm font-bold writing-vertical">{meal.name}</span>
                                  </div>
                                  
                                  {/* Day Slots */}
                                  {days.map((_, dayIdx) => {
                                      const key = `${dayIdx}-${meal.id}`;
                                      const recipe = mealMap[key];
                                      
                                      return (
                                          <div 
                                            key={key}
                                            onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add('ring-2', 'ring-brand-400', 'bg-brand-50'); }}
                                            onDragLeave={(e) => { e.currentTarget.classList.remove('ring-2', 'ring-brand-400', 'bg-brand-50'); }}
                                            onDrop={(e) => { e.currentTarget.classList.remove('ring-2', 'ring-brand-400', 'bg-brand-50'); handleDrop(e, dayIdx, meal.id); }}
                                            draggable
                                            onDragStart={(e) => handleDragStart(e, recipe)}
                                            className="relative group bg-gray-50 dark:bg-gray-700/50 rounded-xl p-2 border border-transparent hover:border-brand-200 dark:hover:border-brand-700 hover:shadow-md transition-all cursor-move active:cursor-grabbing"
                                          >
                                              <div className="aspect-video rounded-lg overflow-hidden mb-2 pointer-events-none">
                                                  <img src={recipe.image} className="w-full h-full object-cover" alt="meal" />
                                              </div>
                                              <div className="text-xs font-bold text-gray-800 dark:text-gray-200 line-clamp-1">{recipe.title}</div>
                                              <div className="text-[10px] text-gray-500 dark:text-gray-400">{recipe.calories} kcal</div>
                                          </div>
                                      );
                                  })}
                              </div>
                          ))}
                      </div>
                  </div>
              </div>

              {/* Sidebar Stats */}
              <div className="w-full lg:w-80 flex flex-col gap-6">
                  {/* Shopping List Card */}
                  <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="font-bold text-lg flex items-center gap-2">
                              <ShoppingBag size={20} /> 采购清单
                          </h3>
                          <span className="bg-white/20 px-2 py-1 rounded text-xs">12 项</span>
                      </div>
                      <div className="space-y-2 mb-4 text-sm text-indigo-100">
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>鸡胸肉</span>
                              <span>500g</span>
                          </div>
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>西兰花</span>
                              <span>2 颗</span>
                          </div>
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>全麦面包</span>
                              <span>1 袋</span>
                          </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <button 
                            onClick={handleCopyList}
                            className="flex items-center justify-center gap-1 bg-white/20 hover:bg-white/30 text-white py-2 rounded-lg font-bold text-xs transition-colors"
                        >
                            <Copy size={14} /> 复制
                        </button>
                        <button 
                            onClick={handleBuy}
                            className="flex items-center justify-center gap-1 bg-white text-indigo-600 py-2 rounded-lg font-bold text-xs hover:bg-indigo-50 transition-colors"
                        >
                            <CreditCard size={14} /> 一键买齐
                        </button>
                      </div>
                  </div>

                  {/* Daily Nutrition */}
                  <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 flex-1">
                      <h3 className="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                          <PieChartIcon className="text-brand-500" size={18} /> 营养概览 (动态)
                      </h3>
                      <div className="h-48 relative flex items-center justify-center">
                          <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                  <Pie
                                      data={[
                                          { name: '碳水', value: 45 },
                                          { name: '蛋白质', value: 30 },
                                          { name: '脂肪', value: 25 },
                                      ]}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={40}
                                      outerRadius={70}
                                      paddingAngle={5}
                                      dataKey="value"
                                  >
                                      <Cell fill="#f97316" /> {/* Orange */}
                                      <Cell fill="#3b82f6" /> {/* Blue */}
                                      <Cell fill="#fbbf24" /> {/* Yellow */}
                                  </Pie>
                              </PieChart>
                          </ResponsiveContainer>
                          <div className="absolute text-center">
                              <div className="text-2xl font-bold text-gray-800 dark:text-white">1850</div>
                              <div className="text-xs text-gray-400">kcal</div>
                          </div>
                      </div>
                      {/* Legend... */}
                  </div>
              </div>
          </div>
      </div>
  );
};

export default MealPlan;