import React, { useState } from 'react';
import { Plus, Search, Bell } from 'lucide-react';
import PostCard, { Post } from './PostCard';
import { toast } from 'sonner';

// Mock Data
const MOCK_POSTS: Post[] = [
  {
    post_id: 'p1',
    image_url: 'https://picsum.photos/id/102/600/800',
    title: '今天的减脂午餐打卡，巨好吃！🥗',
    content: '按照食谱做的，意外的好吃，强烈推荐大家尝试！',
    user: { name: 'HealthSarah', avatar: 'https://picsum.photos/id/64/100/100' },
    likes: 124,
    related_recipe: { id: 'r1', title: '牛油果沙拉' }
  },
  {
    post_id: 'p2',
    image_url: 'https://picsum.photos/id/292/600/800',
    title: '终于学会做红烧肉了，男朋友馋哭了 🍖',
    content: '第一次做这么成功的硬菜。',
    user: { name: 'ChefMike', avatar: 'https://picsum.photos/id/65/100/100' },
    likes: 89,
    related_recipe: { id: 'r2', title: '红烧肉' }
  },
  {
    post_id: 'p3',
    image_url: 'https://picsum.photos/id/312/600/800',
    title: '周末烘焙时光 🍰',
    content: '低卡版本的杯子蛋糕，不用担心长胖。',
    user: { name: 'SweetJane', avatar: 'https://picsum.photos/id/66/100/100' },
    likes: 256,
    related_recipe: { id: 'r1', title: '圣诞杯子蛋糕' }
  },
  {
    post_id: 'p4',
    image_url: 'https://picsum.photos/id/429/600/800',
    title: '清空冰箱挑战！',
    content: '把剩下的蔬菜都炒了，没想到味道还不错。',
    user: { name: 'PantryKing', avatar: 'https://picsum.photos/id/68/100/100' },
    likes: 45
  },
  {
    post_id: 'p5',
    image_url: 'https://picsum.photos/id/493/600/800',
    title: '草莓季不可错过的神仙吃法 🍓',
    content: '酸酸甜甜，满满的维生素C。',
    user: { name: 'BerryLover', avatar: 'https://picsum.photos/id/76/100/100' },
    likes: 1024
  },
  {
    post_id: 'p6',
    image_url: 'https://picsum.photos/id/225/600/800',
    title: '深夜放毒：一碗热腾腾的面',
    content: '加班回来的一碗面，治愈一整天。',
    user: { name: 'LateNight', avatar: 'https://picsum.photos/id/88/100/100' },
    likes: 67,
    related_recipe: { id: 'r4', title: '红烧牛肉面' }
  }
];

const CommunityFeed = () => {
  const [activeTab, setActiveTab] = useState<'recommend' | 'follow' | 'latest'>('recommend');
  const [showPostModal, setShowPostModal] = useState(false);

  const tabs = [
    { id: 'follow', label: '关注' },
    { id: 'recommend', label: '推荐' },
    { id: 'latest', label: '最新' },
  ];

  const handlePost = () => {
      setShowPostModal(false);
      toast.success('动态发布成功！');
  }

  return (
    <div className="pb-20 animate-fade-in relative min-h-screen">
      
      {/* Top Navigation */}
      <div className="sticky top-0 z-30 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md pt-4 pb-2 px-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center justify-between mb-2">
            <div className="flex-1"></div>
            <div className="flex gap-6">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`relative text-base font-bold transition-colors px-2 py-1 ${
                            activeTab === tab.id 
                            ? 'text-gray-900 dark:text-white scale-110' 
                            : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
                        }`}
                    >
                        {tab.label}
                        {activeTab === tab.id && (
                            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-1 bg-brand-500 rounded-full"></div>
                        )}
                    </button>
                ))}
            </div>
            <div className="flex-1 flex justify-end">
                <Search className="text-gray-600 dark:text-gray-300" size={20} />
            </div>
        </div>
      </div>

      {/* Waterfall Feed */}
      <div className="p-4 columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
        {MOCK_POSTS.map((post) => (
           <PostCard key={post.post_id} post={post} onClick={() => toast("进入详情页 (Demo)")} /> 
        ))}
      </div>

      {/* Floating Action Button */}
      <button 
        onClick={() => setShowPostModal(true)}
        className="fixed bottom-24 right-6 bg-brand-500 text-white w-14 h-14 rounded-full shadow-lg shadow-brand-500/40 flex items-center justify-center hover:scale-110 transition-transform z-40"
      >
        <Plus size={28} />
      </button>

      {/* Mock Upload Modal */}
      {showPostModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 sm:p-0">
              <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowPostModal(false)}></div>
              <div className="bg-white dark:bg-gray-800 w-full max-w-md rounded-t-2xl sm:rounded-2xl p-6 relative animate-fade-in-up">
                  <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">发布新动态</h3>
                  <div className="h-40 bg-gray-100 dark:bg-gray-700 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 flex flex-col items-center justify-center text-gray-400 mb-4 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
                      <Plus size={32} />
                      <span className="text-sm mt-2">上传图片/视频</span>
                  </div>
                  <textarea 
                    className="w-full bg-gray-50 dark:bg-gray-700 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 mb-4 dark:text-white"
                    rows={3}
                    placeholder="分享你的美食心得..."
                  ></textarea>
                  <button 
                    onClick={handlePost}
                    className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold hover:bg-brand-600 transition-colors"
                  >
                      发布
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};

export default CommunityFeed;