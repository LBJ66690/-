import { ChatMessage, Recipe } from '../types';
import { MOCK_RECIPES } from '../constants';

// Simulate SSE Stream response
export const streamChatResponse = async (
  userMessage: string,
  onChunk: (chunk: string) => void,
  onComplete: (fullMessage: string, action?: any) => void
) => {
  const isDietChange = userMessage.includes('换') || userMessage.includes('高碳水') || userMessage.includes('不要');
  
  let responseText = '';
  let fullText = '';
  let action: any = null;

  if (isDietChange) {
    fullText = "收到，考虑到您周三有游泳计划，确实需要增加碳水储备。已为您将午餐调整为【经典红烧牛肉面】，这能提供充足的能量。同时排除了您不喜欢的食材。";
    action = {
      type: 'UPDATE_PLAN',
      payload: {
        date: '2024-05-22',
        meal: 'LUNCH',
        oldRecipeId: 'r2',
        newRecipe: MOCK_RECIPES.find(r => r.id === 'r4') || MOCK_RECIPES[3]
      }
    };
  } else {
    fullText = "您好！我是您的智能膳食管家。您可以告诉我您的运动计划或口味偏好，我会为您调整食谱。";
  }

  // Simulate streaming
  const words = fullText.split('');
  for (let i = 0; i < words.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 30)); // 30ms delay per char
    responseText += words[i];
    onChunk(responseText);
  }

  onComplete(fullText, action);
};

export const getHealthStats = () => {
  return [
    { subject: '热量', A: 120, fullMark: 150 },
    { subject: '蛋白质', A: 98, fullMark: 150 },
    { subject: '脂肪', A: 86, fullMark: 150 },
    { subject: '碳水', A: 99, fullMark: 150 },
    { subject: '维生素', A: 85, fullMark: 150 },
    { subject: '膳食纤维', A: 65, fullMark: 150 },
  ];
};

export const getWeightHistory = () => {
  return [
    { date: '12-01', weight: 62 },
    { date: '12-05', weight: 61.5 },
    { date: '12-10', weight: 61.2 },
    { date: '12-15', weight: 60.8 },
    { date: '12-20', weight: 60.5 },
    { date: '12-24', weight: 60.0 },
  ];
};