import React, { useState } from 'react';
import { Send } from 'lucide-react';
import StarRating from './StarRating';
import { toast } from 'sonner';

interface Review {
  id: string;
  user_name: string;
  avatar: string;
  rating: number;
  comment: string;
  created_at: string;
}

// Mock Data
const MOCK_REVIEWS: Review[] = [
  {
    id: 'rv1',
    user_name: 'Alice',
    avatar: 'https://picsum.photos/id/10/100/100',
    rating: 5,
    comment: '非常好吃！孩子特别喜欢，做法也很简单。',
    created_at: '2024-05-20 18:30'
  },
  {
    id: 'rv2',
    user_name: 'Bob',
    avatar: 'https://picsum.photos/id/12/100/100',
    rating: 4,
    comment: '稍微淡了一点，建议多加点盐。',
    created_at: '2024-05-19 12:15'
  },
  {
    id: 'rv3',
    user_name: 'Cathy',
    avatar: 'https://picsum.photos/id/32/100/100',
    rating: 5,
    comment: '完美的周末早餐！',
    created_at: '2024-05-18 09:00'
  }
];

const ReviewSection = () => {
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState(0);

  const avgRating = (reviews.reduce((acc, curr) => acc + curr.rating, 0) / reviews.length).toFixed(1);

  const handleSubmit = () => {
    if (!newComment.trim() || newRating === 0) {
      toast.error('请填写评论内容并打分');
      return;
    }

    const review: Review = {
      id: Date.now().toString(),
      user_name: '我',
      avatar: 'https://picsum.photos/id/64/100/100', // Current User Avatar
      rating: newRating,
      comment: newComment,
      created_at: new Date().toLocaleString()
    };

    setReviews([review, ...reviews]);
    setNewComment('');
    setNewRating(0);
    toast.success('评论发布成功！');
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm mt-8">
      <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-6 border-l-4 border-brand-500 pl-3 flex items-center gap-2">
        食谱评价 
        <span className="text-sm font-normal text-gray-500">({reviews.length}条)</span>
      </h3>

      {/* Summary */}
      <div className="flex items-center gap-4 mb-8 bg-gray-50 dark:bg-gray-700/50 p-4 rounded-xl">
        <div className="text-4xl font-bold text-brand-500">{avgRating}</div>
        <div>
          <StarRating rating={Number(avgRating)} size={18} />
          <div className="text-xs text-gray-400 mt-1">综合评分</div>
        </div>
      </div>

      {/* Input Area */}
      <div className="mb-8">
        <div className="flex gap-4 items-start">
            <img src="https://picsum.photos/id/64/100/100" className="w-10 h-10 rounded-full" alt="Me" />
            <div className="flex-1 space-y-3">
                <div className="bg-gray-100 dark:bg-gray-700 rounded-xl p-4 transition-all focus-within:ring-2 focus-within:ring-brand-200">
                    <textarea 
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="分享您的烹饪心得..."
                        className="w-full bg-transparent border-none focus:outline-none text-sm min-h-[60px] resize-none dark:text-white"
                    />
                    <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-200 dark:border-gray-600">
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500">打分:</span>
                            <StarRating rating={newRating} interactive onRate={setNewRating} />
                        </div>
                        <button 
                            onClick={handleSubmit}
                            className="bg-brand-500 text-white px-4 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 hover:bg-brand-600 transition-colors"
                        >
                            发布 <Send size={12} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* Review List */}
      <div className="space-y-6">
        {reviews.map((review) => (
            <div key={review.id} className="flex gap-4 border-b border-gray-50 dark:border-gray-700 pb-6 last:border-0 last:pb-0 animate-fade-in">
                <img src={review.avatar} alt={review.user_name} className="w-10 h-10 rounded-full" />
                <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                        <div>
                            <span className="font-bold text-gray-800 dark:text-gray-200 text-sm block">{review.user_name}</span>
                            <span className="text-xs text-gray-400">{review.created_at}</span>
                        </div>
                        <StarRating rating={review.rating} size={12} />
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mt-2">{review.comment}</p>
                </div>
            </div>
        ))}
      </div>
    </div>
  );
};

export default ReviewSection;