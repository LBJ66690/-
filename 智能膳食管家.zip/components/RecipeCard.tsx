import React from 'react';
import { Heart, Clock, Flame } from 'lucide-react';
import { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
  onClick: (id: string) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onClick }) => {
  return (
    <div 
      onClick={() => onClick(recipe.id)}
      className="group bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer border border-transparent hover:border-brand-100"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={recipe.image} 
          alt={recipe.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm p-1.5 rounded-full shadow-sm">
          <Heart size={16} className="text-gray-400 hover:text-red-500 transition-colors" />
        </div>
        <div className="absolute bottom-2 left-2 flex gap-2">
            {recipe.tags.slice(0, 2).map(tag => (
                <span key={tag} className="text-[10px] px-2 py-1 bg-black/60 text-white backdrop-blur-md rounded-full">
                    {tag}
                </span>
            ))}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-gray-800 mb-2 truncate">{recipe.title}</h3>
        
        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Clock size={14} className="text-brand-400" />
            <span>{recipe.time} 分钟</span>
          </div>
          <div className="flex items-center gap-1">
            <Flame size={14} className="text-red-400" />
            <span>{recipe.calories} kcal</span>
          </div>
        </div>
        
        <div className="mt-3 flex items-center justify-between">
            <div className="flex text-yellow-400 text-xs">
                {'★'.repeat(Math.floor(recipe.rating))}
                <span className="text-gray-300 ml-1">({recipe.reviews})</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-brand-50 flex items-center justify-center text-brand-500 group-hover:bg-brand-500 group-hover:text-white transition-colors">
                →
            </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeCard;