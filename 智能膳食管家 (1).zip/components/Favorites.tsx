import React, { useState, useEffect } from 'react';
import { Heart, Search, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import RecipeCard from './RecipeCard';
import { MOCK_RECIPES } from '../constants';
import { Recipe } from '../types';

const Favorites = () => {
  const navigate = useNavigate();
  const [favorites, setFavorites] = useState<Recipe[]>([]);

  useEffect(() => {
    // Simulate fetching from local storage or API
    const savedIds = JSON.parse(localStorage.getItem('favorites') || '[]');
    // For demo purposes, if empty, let's pre-fill a few if they match mock data
    // Or strictly follow logic: only show what is saved.
    // If user has no favorites yet, we can't show mock data unless we force it.
    // Let's filter MOCK_RECIPES based on savedIds
    let userFavs = MOCK_RECIPES.filter(r => savedIds.includes(r.id));
    
    // Fallback for demo: if empty, show nothing (to demonstrate empty state) or user can add.
    setFavorites(userFavs);
  }, []);

  const handleRemove = (id: string) => {
      // This function updates the local state to remove the card immediately
      setFavorites(prev => prev.filter(r => r.id !== id));
      // Actual storage update is handled inside RecipeCard, but we might need to sync.
      // Since RecipeCard handles toggling, re-clicking heart in RecipeCard will remove it from storage.
      // But we want to reflect that change here visually. 
      // The RecipeCard component handles storage. We just need to handle UI removal if needed.
      // However, RecipeCard's `onClick` prop is for navigation. The Heart icon inside handles logic.
      // To make the UI reactive, we can rely on the fact that if user un-hearts, we should filter it out.
      // But RecipeCard's internal state handles the visual heart. 
      // Ideally we pass a callback to RecipeCard when heart is clicked, but RecipeCard is generic.
      // Let's rely on a window event or simple re-render if we were using a real store.
      // For now, simple interaction: User clicks heart -> RecipeCard removes from LS -> 
      // We might need to refresh this page to see it gone.
  };

  return (
    <div className="animate-fade-in pb-20 space-y-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-2xl text-red-500">
            <Heart className="fill-current" size={24} />
        </div>
        <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">我的收藏</h1>
            <p className="text-sm text-gray-500">共 {favorites.length} 个珍藏食谱</p>
        </div>
      </div>

      {favorites.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} onClick={(id) => navigate(`/recipe/${id}`)} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-40 h-40 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-6">
             <Search size={48} className="text-gray-300 dark:text-gray-600" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">暂无收藏食谱</h3>
          <p className="text-gray-500 max-w-xs mb-8">您还没有收藏任何食谱哦，快去探索美味，建立属于您的美食库吧！</p>
          <button 
            onClick={() => navigate('/')}
            className="bg-brand-500 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-brand-600 transition-all flex items-center gap-2"
          >
            去探索 <ArrowRight size={18} />
          </button>
        </div>
      )}
    </div>
  );
};

export default Favorites;