import React, { useState } from 'react';
import { Heart, Link as LinkIcon } from 'lucide-react';

export interface Post {
  post_id: string;
  image_url: string;
  title: string;
  content: string;
  user: {
    name: string;
    avatar: string;
  };
  likes: number;
  related_recipe?: {
    id: string;
    title: string;
  };
}

interface PostCardProps {
  post: Post;
  onClick?: () => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, onClick }) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (liked) {
      setLikeCount(prev => prev - 1);
    } else {
      setLikeCount(prev => prev + 1);
    }
    setLiked(!liked);
  };

  return (
    <div 
      onClick={onClick}
      className="break-inside-avoid mb-4 group relative bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer border border-gray-100 dark:border-gray-700"
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-gray-100">
        <img 
          src={post.image_url} 
          alt={post.title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        
        {/* Related Recipe Tag */}
        {post.related_recipe && (
          <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-full flex items-center gap-1 border border-white/20">
            <LinkIcon size={10} />
            <span className="truncate max-w-[80px]">做了: {post.related_recipe.title}</span>
          </div>
        )}
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60"></div>
      </div>

      {/* Content */}
      <div className="absolute bottom-0 inset-x-0 p-3 text-white">
        <h3 className="font-bold text-sm leading-snug line-clamp-2 mb-2 text-shadow-sm">
          {post.title}
        </h3>
        
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1.5">
            <img 
              src={post.user.avatar} 
              alt={post.user.name} 
              className="w-5 h-5 rounded-full border border-white/50"
            />
            <span className="text-xs text-white/90 truncate max-w-[60px]">{post.user.name}</span>
          </div>
          
          <button 
            onClick={handleLike}
            className="flex items-center gap-1 group/btn"
          >
            <Heart 
              size={14} 
              className={`transition-all duration-300 ${liked ? 'fill-red-500 text-red-500 scale-125' : 'text-white group-hover/btn:scale-110'}`} 
            />
            <span className="text-xs font-medium tabular-nums">{likeCount}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default PostCard;