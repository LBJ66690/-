import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, X } from 'lucide-react';
import { ChatMessage } from '../types';
import { streamChatResponse } from '../services/mockService';

interface ChatInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: '你好！我是您的智能膳食管家。检测到您今天运动量较大，是否需要为您调整晚餐方案？',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Placeholder for stream
    const botMsgId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: botMsgId,
      role: 'assistant',
      content: '...',
      timestamp: Date.now()
    }]);

    await streamChatResponse(
      userMsg.content,
      (chunk) => {
        setMessages(prev => prev.map(m => 
          m.id === botMsgId ? { ...m, content: chunk } : m
        ));
      },
      (fullText, action) => {
        setMessages(prev => prev.map(m => 
          m.id === botMsgId ? { ...m, content: fullText, action } : m
        ));
        setIsTyping(false);
      }
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden border border-gray-100 animate-fade-in-up">
      {/* Header */}
      <div className="bg-gradient-to-r from-brand-500 to-brand-600 p-4 flex justify-between items-center text-white">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-white/20 rounded-full">
            <Bot size={20} />
          </div>
          <div>
            <h3 className="font-bold">膳食管家 Agent</h3>
            <p className="text-xs text-brand-100 flex items-center gap-1">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              在线 - 模型 vLLM-72B
            </p>
          </div>
        </div>
        <button onClick={onClose} className="hover:bg-white/20 p-1 rounded transition-colors">
          <X size={20} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl p-3 shadow-sm ${
              msg.role === 'user' 
                ? 'bg-brand-500 text-white rounded-tr-none' 
                : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none'
            }`}>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
              
              {/* Action Card (Structured Output) */}
              {msg.action && msg.action.type === 'UPDATE_PLAN' && (
                <div className="mt-3 bg-brand-50 rounded-xl p-3 border border-brand-100">
                  <div className="text-xs font-bold text-brand-600 mb-2 uppercase tracking-wide">
                    执行操作: 调整食谱
                  </div>
                  <div className="flex gap-3 items-center bg-white p-2 rounded-lg border border-gray-100">
                    <img 
                      src={msg.action.payload.newRecipe.image} 
                      className="w-12 h-12 rounded object-cover" 
                      alt="Recipe"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{msg.action.payload.newRecipe.title}</div>
                      <div className="text-xs text-gray-500">
                        {msg.action.payload.date} · {msg.action.payload.meal}
                      </div>
                    </div>
                  </div>
                  <button className="w-full mt-2 bg-brand-500 hover:bg-brand-600 text-white text-xs py-1.5 rounded transition-colors">
                    确认修改
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t border-gray-100">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="例如：周三要游泳，午餐想吃高碳水..."
            className="flex-1 px-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
            disabled={isTyping}
          />
          <button 
            onClick={handleSend}
            disabled={isTyping || !input.trim()}
            className={`p-2 rounded-full transition-all ${
              input.trim() ? 'bg-brand-500 text-white shadow-md hover:bg-brand-600' : 'bg-gray-200 text-gray-400'
            }`}
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;