import { Recipe, User, HealthInsight } from './types';

export const MOCK_USER: User = {
  id: 'u1',
  name: 'Jim',
  avatar: 'https://picsum.photos/id/64/200/200',
  weight: 60,
  height: 175,
  goal: 'GAIN_MUSCLE',
  allergies: ['Peanuts'],
};

export const MOCK_RECIPES: Recipe[] = [
  {
    id: 'r1',
    title: '圣诞杯子蛋糕',
    image: 'https://picsum.photos/id/431/400/300',
    calories: 320,
    protein: 8,
    fat: 15,
    carbs: 45,
    time: 45,
    tags: ['甜点', '节日', '烘焙'],
    description: '既好看又好吃的节日限定甜点，适合派对分享。',
    ingredients: [
      { name: '鸡蛋', amount: '2个' },
      { name: '低筋粉', amount: '100g' },
      { name: '草莓', amount: '5颗' },
      { name: '淡奶油', amount: '200ml' }
    ],
    steps: ['打发鸡蛋和糖', '筛入面粉搅拌', '烤箱170度20分钟', '装饰奶油和草莓'],
    rating: 4.8,
    reviews: 128
  },
  {
    id: 'r2',
    title: '白玉菇炒火腿',
    image: 'https://picsum.photos/id/292/400/300',
    calories: 180,
    protein: 12,
    fat: 8,
    carbs: 5,
    time: 15,
    tags: ['快手菜', '家常', '低卡'],
    description: '十分钟搞定的营养快手菜，鲜美下饭。',
    ingredients: [
      { name: '白玉菇', amount: '200g' },
      { name: '火腿', amount: '50g' },
      { name: '青椒', amount: '1个' }
    ],
    steps: ['食材洗净切段', '热油爆香葱姜', '放入火腿翻炒', '加入白玉菇炒熟调味'],
    rating: 4.5,
    reviews: 56
  },
  {
    id: 'r3',
    title: '时令鲜果松饼',
    image: 'https://picsum.photos/id/312/400/300',
    calories: 450,
    protein: 10,
    fat: 18,
    carbs: 60,
    time: 25,
    tags: ['早餐', '美式'],
    description: '松软香甜的松饼搭配新鲜浆果。',
    ingredients: [
      { name: '松饼粉', amount: '150g' },
      { name: '牛奶', amount: '100ml' },
      { name: '蓝莓', amount: '50g' }
    ],
    steps: ['混合粉类液体', '平底锅煎至金黄', '淋上蜂蜜摆盘'],
    rating: 4.9,
    reviews: 201
  },
  {
    id: 'r4',
    title: '经典红烧牛肉面',
    image: 'https://picsum.photos/id/225/400/300',
    calories: 650,
    protein: 35,
    fat: 25,
    carbs: 70,
    time: 120,
    tags: ['面食', '传统', '高蛋白'],
    description: '汤浓肉烂，一碗下去暖心暖胃。',
    ingredients: [
      { name: '牛腩', amount: '500g' },
      { name: '手擀面', amount: '200g' },
      { name: '青菜', amount: '2颗' }
    ],
    steps: ['牛肉焯水', '炒糖色炖煮2小时', '煮面烫菜', '组合装盘'],
    rating: 4.7,
    reviews: 89
  }
];

export const MOCK_INSIGHTS: HealthInsight[] = [
  {
    id: 'h1',
    type: 'HIGH_SODIUM',
    message: '检测到今日钠摄入超标（2600mg），建议晚餐避免酱菜。',
    timestamp: '14:30',
    isRead: false
  }
];