import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Settings, Award, Activity, Scale, ChevronRight, Bell, Shield, CircleUser, LogOut } from 'lucide-react';
import { MOCK_USER } from '../constants';

const Profile = () => {
  const navigate = useNavigate();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  // BMI Calculation
  const bmi = (MOCK_USER.weight / ((MOCK_USER.height / 100) ** 2)).toFixed(1);

  return (
    <div className="animate-fade-in pb-20 max-w-4xl mx-auto space-y-6">
      {/* Header Profile Card */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col md:flex-row items-center gap-6">
        <div className="relative">
            <img src={MOCK_USER.avatar} alt="Profile" className="w-24 h-24 rounded-full border-4 border-brand-100 dark:border-brand-900" />
            <div className="absolute bottom-0 right-0 bg-brand-500 text-white p-1.5 rounded-full border-2 border-white dark:border-gray-800">
                <Award size={14} />
            </div>
        </div>
        <div className="flex-1 text-center md:text-left">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{MOCK_USER.name}</h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm">高级会员 · 加入时间 2023-11</p>
            <div className="flex items-center justify-center md:justify-start gap-2 mt-2">
                <span className="bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 px-3 py-1 rounded-full text-xs font-bold">
                    {MOCK_USER.goal === 'LOSE_WEIGHT' ? '减脂模式' : MOCK_USER.goal === 'GAIN_MUSCLE' ? '增肌模式' : '保持健康'}
                </span>
                <span className="bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full text-xs font-bold">
                    LV.4 美食家
                </span>
            </div>
        </div>
        <button className="px-6 py-2 border border-gray-200 dark:border-gray-600 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium dark:text-gray-300">
            编辑资料
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center py-8">
            <Scale className="text-brand-500 mb-2" size={24} />
            <div className="text-2xl font-bold text-gray-800 dark:text-white">{MOCK_USER.weight}<span className="text-sm font-normal text-gray-400 ml-1">kg</span></div>
            <div className="text-xs text-gray-500 dark:text-gray-400">当前体重</div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center py-8">
            <Activity className="text-green-500 mb-2" size={24} />
            <div className="text-2xl font-bold text-gray-800 dark:text-white">{bmi}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">BMI 指数</div>
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center py-8">
             <div className="text-2xl font-bold text-orange-500 mb-2">🔥 12</div>
             <div className="text-2xl font-bold text-gray-800 dark:text-white">Day</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">连续打卡</div>
        </div>
      </div>

      {/* Detail Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Health Data */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
              <h3 className="font-bold text-lg mb-4 text-gray-800 dark:text-white flex items-center gap-2">
                  <User size={20} className="text-gray-400" /> 身体档案
              </h3>
              <div className="space-y-4 text-sm">
                  <div className="flex justify-between items-center py-2 border-b border-gray-50 dark:border-gray-700">
                      <span className="text-gray-500 dark:text-gray-400">身高</span>
                      <span className="font-medium text-gray-800 dark:text-white">{MOCK_USER.height} cm</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-gray-50 dark:border-gray-700">
                      <span className="text-gray-500 dark:text-gray-400">年龄</span>
                      <span className="font-medium text-gray-800 dark:text-white">28 岁</span>
                  </div>
                   <div className="flex justify-between items-center py-2 border-b border-gray-50 dark:border-gray-700">
                      <span className="text-gray-500 dark:text-gray-400">过敏源</span>
                      <div className="flex gap-1">
                          {MOCK_USER.allergies.map(a => (
                              <span key={a} className="text-xs bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-2 py-1 rounded">{a}</span>
                          ))}
                      </div>
                  </div>
                  <div className="flex justify-between items-center py-2">
                      <span className="text-gray-500 dark:text-gray-400">饮食偏好</span>
                      <span className="font-medium text-gray-800 dark:text-white">低碳水, 高蛋白</span>
                  </div>
              </div>
          </div>

          {/* Settings Menu */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
              <h3 className="font-bold text-lg mb-4 text-gray-800 dark:text-white flex items-center gap-2">
                  <Settings size={20} className="text-gray-400" /> 账户设置
              </h3>
              <div className="space-y-2">
                  <button className="w-full flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors">
                      <div className="flex items-center gap-3">
                          <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg text-blue-500"><Bell size={18} /></div>
                          <span className="text-gray-700 dark:text-gray-200 font-medium text-sm">消息通知</span>
                      </div>
                      <div 
                        onClick={(e) => { e.stopPropagation(); setNotificationsEnabled(!notificationsEnabled); }}
                        className={`w-10 h-6 rounded-full p-1 transition-colors cursor-pointer ${notificationsEnabled ? 'bg-brand-500' : 'bg-gray-300 dark:bg-gray-600'}`}
                      >
                          <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${notificationsEnabled ? 'translate-x-4' : ''}`}></div>
                      </div>
                  </button>

                  <button className="w-full flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors">
                      <div className="flex items-center gap-3">
                          <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded-lg text-green-500"><Shield size={18} /></div>
                          <span className="text-gray-700 dark:text-gray-200 font-medium text-sm">隐私与安全</span>
                      </div>
                      <ChevronRight size={16} className="text-gray-400" />
                  </button>

                   <button className="w-full flex justify-between items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-xl transition-colors">
                      <div className="flex items-center gap-3">
                          <div className="bg-purple-50 dark:bg-purple-900/20 p-2 rounded-lg text-purple-500"><CircleUser size={18} /></div>
                          <span className="text-gray-700 dark:text-gray-200 font-medium text-sm">账户管理</span>
                      </div>
                      <ChevronRight size={16} className="text-gray-400" />
                  </button>

                  <div className="border-t border-gray-100 dark:border-gray-700 my-2"></div>

                   <button 
                    onClick={() => { localStorage.clear(); navigate('/login'); }}
                    className="w-full flex items-center gap-3 p-3 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors text-red-500"
                   >
                      <div className="p-2"><LogOut size={18} /></div>
                      <span className="font-medium text-sm">退出登录</span>
                  </button>
              </div>
          </div>
      </div>
    </div>
  );
};

export default Profile;