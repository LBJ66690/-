import React from 'react';
import { Sparkles, TrendingUp, TrendingDown, ArrowRight, Quote } from 'lucide-react';
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useNavigate } from 'react-router-dom';

const WeeklyReport = () => {
  const navigate = useNavigate();
  
  // Mock Data for Sparklines
  const weightData = [
    { d: 'M', v: 61.2 }, { d: 'T', v: 61.0 }, { d: 'W', v: 60.8 }, 
    { d: 'T', v: 61.1 }, { d: 'F', v: 60.5 }, { d: 'S', v: 60.2 }, { d: 'S', v: 60.0 }
  ];
  
  const calData = [
    { d: 'M', v: 1800 }, { d: 'T', v: 1750 }, { d: 'W', v: 2100 }, 
    { d: 'T', v: 1600 }, { d: 'F', v: 1900 }, { d: 'S', v: 2200 }, { d: 'S', v: 1850 }
  ];

  return (
    <div className="animate-fade-in pb-20 max-w-5xl mx-auto">
      {/* Dynamic Banner */}
      <div className="relative h-64 rounded-3xl overflow-hidden mb-10 shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-600 via-brand-500 to-purple-600"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
        <div className="absolute inset-0 flex flex-col justify-center px-10 text-white">
          <div className="flex items-center gap-2 mb-2 opacity-80">
            <Sparkles size={18} className="text-yellow-300" />
            <span className="font-mono text-sm tracking-widest uppercase">AI Generated Insight</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
            "减脂成效<span className="border-b-4 border-yellow-400">显著</span>，但需警惕<br/>周三的碳水反弹"
          </h1>
          <p className="text-brand-100 max-w-xl text-lg">基于您过去7天的 21 顿餐饮及运动数据分析生成。</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        
        {/* Main Narrative Column */}
        <div className="lg:col-span-2 space-y-10">
          
          {/* Section 1 */}
          <section className="prose prose-lg text-gray-600">
            <h3 className="flex items-center gap-3 text-2xl font-bold text-gray-800 mb-6">
              <span className="bg-brand-100 text-brand-600 w-8 h-8 rounded-lg flex items-center justify-center text-sm">01</span>
              体重管理深度解读
            </h3>
            <p className="leading-relaxed">
              本周您的体重总体呈下降趋势，累计减轻 <strong className="text-green-600 bg-green-50 px-1 rounded">-1.2kg</strong>。
              这主要得益于您在周一至周二严格控制了晚餐的碳水摄入。然而，数据显示周四出现了一次轻微波动，
              AI 分析认为这与当晚的“聚餐”有关。
            </p>
            
            {/* Embedded Sparkline Chart */}
            <div className="my-6 p-6 bg-white rounded-2xl shadow-sm border border-gray-100 flex items-center gap-6">
               <div className="flex-1">
                 <div className="text-sm text-gray-500 mb-1">近7日体重走势</div>
                 <div className="text-2xl font-bold text-gray-800">60.0 <span className="text-sm font-normal text-gray-400">kg</span></div>
               </div>
               <div className="w-48 h-16">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={weightData}>
                      <defs>
                        <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <Area type="monotone" dataKey="v" stroke="#f97316" strokeWidth={2} fillOpacity={1} fill="url(#colorWeight)" />
                    </AreaChart>
                 </ResponsiveContainer>
               </div>
            </div>

            <p className="leading-relaxed">
              值得表扬的是，您的<strong>基础代谢率</strong>随着高蛋白饮食的摄入略有提升。
              保持目前的蛋白质摄入量（平均 1.5g/kg），预计下周将突破平台期。
            </p>
          </section>

          {/* Section 2 */}
          <section className="prose prose-lg text-gray-600 border-t border-gray-100 pt-10">
            <h3 className="flex items-center gap-3 text-2xl font-bold text-gray-800 mb-6">
              <span className="bg-blue-100 text-blue-600 w-8 h-8 rounded-lg flex items-center justify-center text-sm">02</span>
              热量缺口与饮食结构
            </h3>
            <div className="float-right ml-6 mb-4 w-40 bg-gray-50 p-3 rounded-xl border border-gray-100">
               <div className="text-xs text-center text-gray-400 mb-2">周三热量峰值</div>
               <div className="h-24">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={calData}>
                       <Bar dataKey="v" fill="#cbd5e1" radius={[2,2,0,0]} />
                    </BarChart>
                 </ResponsiveContainer>
               </div>
            </div>
            <p className="leading-relaxed">
              周三的热量摄入达到了峰值 <strong className="text-red-500">2100 kcal</strong>，主要来源于午餐的“红烧肉”。
              虽然脂肪摄入超标，但您当晚进行了 45 分钟的游泳，成功消耗了多余热量。
              这种<span className="underline decoration-brand-300 decoration-2">“欺骗餐 + 高强度运动”</span>的模式是可持续的。
            </p>
          </section>

        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          {/* Highlights Card */}
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 text-white shadow-xl">
             <h4 className="font-bold flex items-center gap-2 mb-6 text-yellow-400">
                <Quote size={18} className="fill-current" /> 本周高光
             </h4>
             <div className="space-y-4">
                <div className="flex gap-3 items-start">
                   <div className="bg-white/10 p-2 rounded-lg text-xl">🏆</div>
                   <div>
                      <div className="font-bold text-sm">最自律的一天</div>
                      <div className="text-xs text-gray-400">周五 · 完美达成三大营养素比例</div>
                   </div>
                </div>
                <div className="flex gap-3 items-start">
                   <div className="bg-white/10 p-2 rounded-lg text-xl">🥗</div>
                   <div>
                      <div className="font-bold text-sm">最佳食谱</div>
                      <div className="text-xs text-gray-400">牛油果鲜虾沙拉 · 饱腹感强</div>
                   </div>
                </div>
             </div>
          </div>

          {/* Action Plan */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-brand-100">
             <h4 className="font-bold text-gray-800 mb-4">下周策略 (Next Steps)</h4>
             <ul className="space-y-3">
                {[
                    '增加早餐的粗粮比例至 50%',
                    '周二尝试“轻断食”晚餐',
                    '将饮水量提升至 2.5L/天'
                ].map((item, i) => (
                    <li key={i} className="flex gap-2 text-sm text-gray-600">
                        <span className="text-brand-500 font-bold">•</span>
                        {item}
                    </li>
                ))}
             </ul>
             <button 
                onClick={() => navigate('/plan')}
                className="w-full mt-6 bg-brand-500 hover:bg-brand-600 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-brand-200 flex items-center justify-center gap-2"
             >
                应用下周计划 <ArrowRight size={16} />
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeeklyReport;