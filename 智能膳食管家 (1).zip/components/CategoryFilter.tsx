import React, { useState } from 'react';

interface CategoryFilterProps {
  onSelect: (category: string) => void;
}

const CATEGORIES = [
  { id: 'all', label: '全部' },
  { id: 'low-carb', label: '🥗 低脂轻食' },
  { id: 'muscle', label: '💪 增肌蛋白' },
  { id: 'quick', label: '⚡️ 快手菜' },
  { id: 'sichuan', label: '🌶️ 川湘风味' },
  { id: 'cantonese', label: '🍲 粤式清淡' },
  { id: 'western', label: '🍝 西餐烘焙' },
  { id: 'japanese', label: '🍱 日式料理' },
  { id: 'seafood', label: '🍤 海鲜水产' },
];

const CategoryFilter: React.FC<CategoryFilterProps> = ({ onSelect }) => {
  const [active, setActive] = useState('all');

  const handleClick = (id: string) => {
    setActive(id);
    onSelect(id);
  };

  return (
    <div className="w-full overflow-x-auto pb-2 scrollbar-hide">
      <div className="flex gap-3 min-w-max px-1">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => handleClick(cat.id)}
            className={`px-4 py-2 rounded-full text-sm font-bold transition-all border ${
              active === cat.id
                ? 'bg-brand-500 text-white border-brand-500 shadow-md shadow-brand-200'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategoryFilter;