import React, { useState, useMemo } from 'react';
import { 
    ChevronLeft, ChevronRight, Sparkles, Droplets, Flame, Utensils, 
    Calendar, RefreshCw, PieChart as PieChartIcon, X, CheckCircle2, RotateCw
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { MOCK_RECIPES } from '../constants';
import { Recipe } from '../types';
import { toast } from 'sonner';
import SmartShoppingList from './SmartShoppingList';

const MealPlan = () => {
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const [currentWeek, setCurrentWeek] = useState('2024.05.20 - 2024.05.26');
  
  // State for drag and drop simulation
  const [mealMap, setMealMap] = useState<Record<string, Recipe>>(() => {
      const initial: Record<string, Recipe> = {};
      days.forEach((_, dIdx) => {
          ['breakfast', 'lunch', 'dinner'].forEach((mType) => {
             const seed = dIdx + mType.length;
             initial[`${dIdx}-${mType}`] = MOCK_RECIPES[seed % MOCK_RECIPES.length];
          });
      });
      return initial;
  });

  const [draggedRecipe, setDraggedRecipe] = useState<Recipe | null>(null);

  // Regeneration State
  const [regenerateModal, setRegenerateModal] = useState<{isOpen: boolean, dayIdx: number, mealId: string} | null>(null);
  const [regenOption, setRegenOption] = useState('strict');
  const [loadingMap, setLoadingMap] = useState<Record<string, boolean>>({});

  const handleDragStart = (e: React.DragEvent, recipe: Recipe) => {
      setDraggedRecipe(recipe);
      e.dataTransfer.effectAllowed = 'move';
  };

  const handleDrop = (e: React.DragEvent, dayIdx: number, mealId: string) => {
      e.preventDefault();
      if (draggedRecipe) {
          const key = `${dayIdx}-${mealId}`;
          setMealMap(prev => ({
              ...prev,
              [key]: draggedRecipe
          }));
          toast.success(`已更新 ${days[dayIdx]} 的膳食`);
          setDraggedRecipe(null);
      }
  };

  const openRegenerate = (dayIdx: number, mealId: string) => {
      setRegenerateModal({ isOpen: true, dayIdx, mealId });
  };

  const handleRegenerateConfirm = () => {
      if (!regenerateModal) return;
      const { dayIdx, mealId } = regenerateModal;
      const key = `${dayIdx}-${mealId}`;

      setRegenerateModal(null);
      setLoadingMap(prev => ({ ...prev, [key]: true }));

      // Simulate AI Latency
      setTimeout(() => {
          // Pick a random different recipe
          const current = mealMap[key];
          let candidate = MOCK_RECIPES.find(r => r.id !== current.id) || MOCK_RECIPES[0];
          
          if (regenOption === 'lighter') {
             // Find lower calories
             const lighter = MOCK_RECIPES.find(r => r.calories < current.calories && r.id !== current.id);
             if (lighter) candidate = lighter;
          }

          setMealMap(prev => ({ ...prev, [key]: candidate }));
          setLoadingMap(prev => ({ ...prev, [key]: false }));
          
          toast.custom((t) => (
             <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-green-100 p-4 flex items-center gap-3">
                <div className="bg-green-100 p-2 rounded-full text-green-600"><CheckCircle2 size={18} /></div>
                <div>
                    <div className="font-bold text-sm text-gray-800 dark:text-white">已为您找到 "{candidate.title}"</div>
                    <div className="text-xs text-gray-500">
                        {regenOption === 'lighter' ? `热量减少 ${current.calories - candidate.calories} kcal` : '符合您的口味偏好'}
                    </div>
                </div>
             </div>
          ));
      }, 2000);
  };

  const meals = [
      { id: 'breakfast', name: '早餐', icon: <Droplets size={16} className="text-blue-400" /> }, 
      { id: 'lunch', name: '午餐', icon: <Flame size={16} className="text-orange-400" /> }, 
      { id: 'dinner', name: '晚餐', icon: <Utensils size={16} className="text-indigo-400" /> }
  ];

  // Derive all recipes for shopping list
  const allRecipes = useMemo(() => Object.values(mealMap), [mealMap]);

  return (
      <div className="h-full flex flex-col gap-6 animate-fade-in pb-20 relative">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-center bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
              <div className="flex items-center gap-4 mb-4 md:mb-0">
                  <div className="bg-brand-50 dark:bg-brand-900/20 p-2 rounded-lg">
                      <Calendar className="text-brand-500" size={24} />
                  </div>
                  <div>
                      <h1 className="text-xl font-bold text-gray-800 dark:text-white">本周膳食计划</h1>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{currentWeek}</p>
                  </div>
              </div>
              <div className="flex gap-2 items-center">
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg dark:text-gray-300"><ChevronLeft size={20} /></button>
                  <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 rounded-lg text-sm font-bold text-gray-700 dark:text-gray-200">本周</button>
                  <button className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg dark:text-gray-300"><ChevronRight size={20} /></button>
                  <div className="h-6 w-px bg-gray-200 dark:bg-gray-600 mx-2"></div>
                  <button className="hidden md:flex items-center gap-2 bg-brand-500 text-white px-4 py-2 rounded-lg font-bold shadow hover:bg-brand-600 transition-colors">
                      <Sparkles size={16} />
                      AI 重新生成
                  </button>
              </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[600px]">
              {/* Calendar Grid with Drag and Drop */}
              <div className="flex-1 bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4 overflow-x-auto border border-gray-100 dark:border-gray-700">
                  <div className="min-w-[800px] h-full flex flex-col">
                      {/* Days Header */}
                      <div className="grid grid-cols-8 gap-4 mb-4 pb-2 border-b border-gray-100 dark:border-gray-700">
                          <div className="font-bold text-gray-400 text-sm flex items-end">时段</div>
                          {days.map((day, i) => (
                              <div key={day} className="text-center">
                                  <div className="text-xs text-gray-400">5/{20+i}</div>
                                  <div className={`font-bold ${i===2 ? 'text-brand-500' : 'text-gray-700 dark:text-gray-300'}`}>{day}</div>
                              </div>
                          ))}
                      </div>

                      {/* Meal Rows */}
                      <div className="flex-1 space-y-4">
                          {meals.map((meal) => (
                              <div key={meal.id} className="grid grid-cols-8 gap-4 min-h-[140px]">
                                  {/* Row Label */}
                                  <div className="flex flex-col justify-center items-center gap-2 text-gray-500 bg-gray-50/50 dark:bg-gray-700/30 rounded-xl">
                                      {meal.icon}
                                      <span className="text-sm font-bold writing-vertical">{meal.name}</span>
                                  </div>
                                  
                                  {/* Day Slots */}
                                  {days.map((_, dayIdx) => {
                                      const key = `${dayIdx}-${meal.id}`;
                                      const recipe = mealMap[key];
                                      const isLoading = loadingMap[key];
                                      
                                      return (
                                          <div 
                                            key={key}
                                            onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add('ring-2', 'ring-brand-400', 'bg-brand-50'); }}
                                            onDragLeave={(e) => { e.currentTarget.classList.remove('ring-2', 'ring-brand-400', 'bg-brand-50'); }}
                                            onDrop={(e) => { e.currentTarget.classList.remove('ring-2', 'ring-brand-400', 'bg-brand-50'); handleDrop(e, dayIdx, meal.id); }}
                                            draggable={!isLoading}
                                            onDragStart={(e) => !isLoading && handleDragStart(e, recipe)}
                                            className={`relative group bg-gray-50 dark:bg-gray-700/50 rounded-xl p-2 border border-transparent hover:border-brand-200 dark:hover:border-brand-700 hover:shadow-md transition-all ${isLoading ? 'animate-pulse cursor-wait' : 'cursor-move'}`}
                                          >
                                              {isLoading ? (
                                                  <div className="space-y-2">
                                                      <div className="h-16 bg-gray-200 dark:bg-gray-600 rounded-lg"></div>
                                                      <div className="h-3 bg-gray-200 dark:bg-gray-600 rounded w-3/4"></div>
                                                      <div className="h-2 bg-gray-200 dark:bg-gray-600 rounded w-1/2"></div>
                                                  </div>
                                              ) : (
                                                  <>
                                                      <div className="aspect-video rounded-lg overflow-hidden mb-2 pointer-events-none">
                                                          <img src={recipe.image} className="w-full h-full object-cover" alt="meal" />
                                                      </div>
                                                      <div className="text-xs font-bold text-gray-800 dark:text-gray-200 line-clamp-1">{recipe.title}</div>
                                                      <div className="text-[10px] text-gray-500 dark:text-gray-400">{recipe.calories} kcal</div>

                                                      {/* Smart Regenerate Trigger */}
                                                      <button 
                                                          onClick={(e) => { e.stopPropagation(); openRegenerate(dayIdx, meal.id); }}
                                                          className="absolute top-1 right-1 p-1 bg-white/80 dark:bg-black/50 backdrop-blur rounded-full text-gray-500 hover:text-brand-500 hover:bg-white transition-colors opacity-0 group-hover:opacity-100"
                                                          title="换一换"
                                                      >
                                                          <RefreshCw size={12} />
                                                      </button>
                                                  </>
                                              )}
                                          </div>
                                      );
                                  })}
                              </div>
                          ))}
                      </div>
                  </div>
              </div>

              {/* Sidebar Stats */}
              <div className="w-full lg:w-80 flex flex-col gap-6">
                  {/* Replaced old list with SmartShoppingList */}
                  <div className="flex-1 min-h-[400px]">
                      <SmartShoppingList recipes={allRecipes} />
                  </div>

                  {/* Daily Nutrition */}
                  <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
                      <h3 className="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                          <PieChartIcon className="text-brand-500" size={18} /> 营养概览 (动态)
                      </h3>
                      <div className="h-48 relative flex items-center justify-center">
                          <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                  <Pie
                                      data={[
                                          { name: '碳水', value: 45 },
                                          { name: '蛋白质', value: 30 },
                                          { name: '脂肪', value: 25 },
                                      ]}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={40}
                                      outerRadius={70}
                                      paddingAngle={5}
                                      dataKey="value"
                                  >
                                      <Cell fill="#f97316" /> {/* Orange */}
                                      <Cell fill="#3b82f6" /> {/* Blue */}
                                      <Cell fill="#fbbf24" /> {/* Yellow */}
                                  </Pie>
                              </PieChart>
                          </ResponsiveContainer>
                          <div className="absolute text-center">
                              <div className="text-2xl font-bold text-gray-800 dark:text-white">1850</div>
                              <div className="text-xs text-gray-400">kcal</div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          {/* Regenerate Popover Modal */}
          {regenerateModal?.isOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                  <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setRegenerateModal(null)}></div>
                  <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl p-6 w-full max-w-sm relative animate-fade-in-up border border-white/20">
                      <button onClick={() => setRegenerateModal(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"><X size={20} /></button>
                      
                      <div className="flex items-center gap-3 mb-6">
                          <div className="bg-brand-100 p-3 rounded-full text-brand-600"><RotateCw size={24} /></div>
                          <div>
                              <h3 className="font-bold text-lg text-gray-800 dark:text-white">想换个口味？</h3>
                              <p className="text-xs text-gray-500">AI 将为您寻找最佳替代方案</p>
                          </div>
                      </div>

                      <div className="space-y-3 mb-6">
                          {[
                              { id: 'strict', label: '严格等价', desc: '热量偏差 ±50kcal，营养一致' },
                              { id: 'lighter', label: '更清淡', desc: '热量 -200kcal，减少油脂' },
                              { id: 'quick', label: '更快捷', desc: '烹饪时间 < 20分钟' },
                              { id: 'pantry', label: '基于库存', desc: '优先使用冰箱现有食材' },
                          ].map(opt => (
                              <label key={opt.id} className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${regenOption === opt.id ? 'bg-brand-50 border-brand-500 ring-1 ring-brand-500' : 'border-gray-200 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800'}`}>
                                  <input 
                                    type="radio" 
                                    name="regenOption" 
                                    className="mt-1"
                                    checked={regenOption === opt.id}
                                    onChange={() => setRegenOption(opt.id)}
                                  />
                                  <div>
                                      <div className="font-bold text-sm text-gray-800 dark:text-white">{opt.label}</div>
                                      <div className="text-xs text-gray-500">{opt.desc}</div>
                                  </div>
                              </label>
                          ))}
                      </div>

                      <button 
                        onClick={handleRegenerateConfirm}
                        className="w-full bg-brand-500 hover:bg-brand-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-brand-200 flex items-center justify-center gap-2"
                      >
                          <Sparkles size={18} /> AI 生成新建议
                      </button>
                  </div>
              </div>
          )}
      </div>
  );
};

export default MealPlan;