import React, { useState, useMemo } from 'react';
import { ShoppingBag, Copy, Check, PieChart as PieChartIcon, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { Recipe } from '../types';

interface SmartShoppingListProps {
  recipes: Recipe[];
}

interface ShoppingItem {
  name: string;
  totalAmount: number;
  unit: string;
  originalStr: string[]; // Keep track of original strings for debug or fallback
  category: string;
  checked: boolean;
}

const SmartShoppingList: React.FC<SmartShoppingListProps> = ({ recipes }) => {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  // Mock categorizer
  const categorize = (name: string): string => {
    if (['鸡胸肉', '牛肉', '虾仁', '火腿', '牛腩'].some(k => name.includes(k))) return '肉禽水产';
    if (['西兰花', '胡萝卜', '番茄', '生菜', '洋葱', '青菜', '青椒', '白玉菇', '草莓', '蓝莓'].some(k => name.includes(k))) return '新鲜蔬果';
    if (['鸡蛋', '牛奶', '芝士', '淡奶油'].some(k => name.includes(k))) return '蛋奶烘焙';
    if (['米饭', '意面', '吐司', '松饼粉', '面条', '手擀面', '低筋粉'].some(k => name.includes(k))) return '粮油副食';
    return '其他调味';
  };

  // Aggregation Logic
  const shoppingList = useMemo(() => {
    const map = new Map<string, ShoppingItem>();

    recipes.forEach(recipe => {
      recipe.ingredients.forEach(ing => {
        const key = ing.name;
        // Mock parsing logic: "500g" -> 500, "2个" -> 2
        const amountMatch = ing.amount.match(/(\d+)(\D+)/);
        const amountVal = amountMatch ? parseInt(amountMatch[1]) : 1;
        const unit = amountMatch ? amountMatch[2] : '份';

        if (map.has(key)) {
          const existing = map.get(key)!;
          // Simple merge if units match (Mock limitation)
          if (existing.unit === unit) {
            existing.totalAmount += amountVal;
            existing.originalStr.push(ing.amount);
          }
        } else {
          map.set(key, {
            name: key,
            totalAmount: amountVal,
            unit: unit,
            originalStr: [ing.amount],
            category: categorize(key),
            checked: false
          });
        }
      });
    });

    // Group by category
    const grouped: Record<string, ShoppingItem[]> = {};
    Array.from(map.values()).forEach(item => {
        if (!grouped[item.category]) grouped[item.category] = [];
        grouped[item.category].push(item);
    });

    return grouped;
  }, [recipes]);

  const totalItems = Object.values(shoppingList).reduce((acc, list) => acc + list.length, 0);
  const checkedCount = checkedItems.size;
  const progress = totalItems > 0 ? (checkedCount / totalItems) * 100 : 0;

  const toggleCheck = (name: string) => {
    const newSet = new Set(checkedItems);
    if (newSet.has(name)) newSet.delete(name);
    else newSet.add(name);
    setCheckedItems(newSet);
  };

  const handleCopy = () => {
    let text = "🛒 采购清单 (DietMaster)\n\n";
    Object.entries(shoppingList).forEach(([cat, items]) => {
      text += `【${cat}】\n`;
      items.forEach(item => {
        text += `- ${item.name}: ${item.totalAmount}${item.unit}\n`;
      });
      text += "\n";
    });
    navigator.clipboard.writeText(text);
    toast.success("已复制到剪贴板");
  };

  return (
    <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg flex flex-col h-full">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-lg flex items-center gap-2">
          <ShoppingBag size={20} /> 采购清单
        </h3>
        <button 
           onClick={handleCopy}
           className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
           title="复制清单"
        >
           <Copy size={16} />
        </button>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-xs text-indigo-100 mb-2">
           <span>采购进度</span>
           <span>{checkedCount}/{totalItems}</span>
        </div>
        <div className="h-1.5 bg-black/20 rounded-full overflow-hidden">
           <div className="h-full bg-white/90 transition-all duration-500 rounded-full" style={{width: `${progress}%`}}></div>
        </div>
      </div>

      {/* List Content */}
      <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-6">
         {Object.entries(shoppingList).map(([category, items]) => (
            <div key={category}>
               <h4 className="text-xs font-bold text-indigo-200 uppercase tracking-wider mb-2">{category}</h4>
               <div className="space-y-2">
                  {items.map(item => {
                     const isChecked = checkedItems.has(item.name);
                     return (
                        <div 
                           key={item.name}
                           onClick={() => toggleCheck(item.name)}
                           className={`flex justify-between items-center p-2 rounded-lg cursor-pointer transition-all ${
                              isChecked ? 'bg-indigo-900/30 text-indigo-300' : 'bg-white/10 hover:bg-white/20'
                           }`}
                        >
                           <div className="flex items-center gap-3">
                              <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                                 isChecked ? 'bg-indigo-400 border-transparent' : 'border-white/40'
                              }`}>
                                 {isChecked && <Check size={12} className="text-white" />}
                              </div>
                              <span className={isChecked ? 'line-through' : ''}>{item.name}</span>
                           </div>
                           <span className="font-mono text-sm opacity-80">{item.totalAmount}{item.unit}</span>
                        </div>
                     );
                  })}
               </div>
            </div>
         ))}
      </div>

      {/* Footer */}
      <div className="mt-6 pt-4 border-t border-white/10 flex justify-between items-center">
         <span className="text-xs text-indigo-200">预估花费 ¥{(totalItems * 8.5).toFixed(1)}</span>
         <button className="flex items-center gap-1 text-xs font-bold hover:underline">
             去电商购买 <ArrowRight size={12} />
         </button>
      </div>
    </div>
  );
};

export default SmartShoppingList;