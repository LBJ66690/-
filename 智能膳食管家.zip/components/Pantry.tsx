import React, { useState } from 'react';
import { Plus, Search, ChefHat, Trash2, AlertCircle, Camera } from 'lucide-react';
import { PantryItem } from '../types';
import { toast } from 'sonner';

const MOCK_PANTRY: PantryItem[] = [
    { id: '1', name: '鸡胸肉', category: 'PROTEIN', quantity: '500g', expiryDays: 3, image: 'https://picsum.photos/id/102/100/100' },
    { id: '2', name: '西兰花', category: 'VEG', quantity: '2个', expiryDays: 5, image: 'https://picsum.photos/id/201/100/100' },
    { id: '3', name: '鸡蛋', category: 'PROTEIN', quantity: '8个', expiryDays: 12, image: 'https://picsum.photos/id/301/100/100' },
    { id: '4', name: '全麦面包', category: 'CARB', quantity: '半袋', expiryDays: 1, image: 'https://picsum.photos/id/401/100/100' },
];

const Pantry = () => {
    const [items, setItems] = useState<PantryItem[]>(MOCK_PANTRY);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const handleCamera = () => {
        setIsAnalyzing(true);
        // Simulate AI Vision analysis
        setTimeout(() => {
            setIsAnalyzing(false);
            const newItem: PantryItem = { 
                id: Date.now().toString(), 
                name: '牛油果', 
                category: 'FRUIT', 
                quantity: '2个', 
                expiryDays: 7,
                image: 'https://picsum.photos/id/500/100/100'
            };
            setItems(prev => [newItem, ...prev]);
            toast.success('AI 识别成功！', {
                description: '已自动添加：牛油果 x2',
                icon: <Camera size={16} />
            });
        }, 2000);
    };

    const getExpiryColor = (days: number) => {
        if (days <= 2) return 'bg-red-100 text-red-600 border-red-200';
        if (days <= 5) return 'bg-yellow-100 text-yellow-600 border-yellow-200';
        return 'bg-green-100 text-green-600 border-green-200';
    };

    return (
        <div className="space-y-6 animate-fade-in pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700">
                <div>
                    <h1 className="text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
                        我的智能冰箱
                        <span className="bg-brand-100 text-brand-600 text-xs px-2 py-1 rounded-full">{items.length} 种食材</span>
                    </h1>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">AI 实时监控保质期，助您减少浪费</p>
                </div>
                <div className="flex gap-3">
                    <button 
                        onClick={handleCamera}
                        disabled={isAnalyzing}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl hover:bg-gray-200 transition-colors font-medium"
                    >
                        {isAnalyzing ? (
                            <>
                                <div className="w-4 h-4 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                                识别中...
                            </>
                        ) : (
                            <>
                                <Camera size={18} /> 拍照录入
                            </>
                        )}
                    </button>
                    <button 
                        className="flex items-center gap-2 px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white rounded-xl shadow-lg shadow-brand-200 transition-all font-bold"
                        onClick={() => toast.info('请在聊天窗口使用“清冰箱”功能')}
                    >
                        <ChefHat size={18} /> 
                        智能组菜
                    </button>
                </div>
            </div>

            {/* Expiring Soon Alert */}
            {items.some(i => i.expiryDays <= 2) && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800 rounded-xl p-4 flex items-center gap-3 text-red-800 dark:text-red-300">
                    <AlertCircle className="shrink-0" />
                    <div className="flex-1">
                        <span className="font-bold">注意！</span> 有 {items.filter(i => i.expiryDays <= 2).length} 种食材即将过期，建议今晚优先食用。
                    </div>
                    <button className="text-sm font-bold underline hover:text-red-900">查看食谱推荐</button>
                </div>
            )}

            {/* Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {/* Add New Card */}
                <div className="aspect-[4/5] border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-2xl flex flex-col items-center justify-center text-gray-400 hover:border-brand-400 hover:text-brand-500 cursor-pointer transition-all bg-gray-50 dark:bg-gray-800/50">
                    <Plus size={32} />
                    <span className="text-sm font-bold mt-2">手动添加</span>
                </div>

                {items.map(item => (
                    <div key={item.id} className="group relative bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-all border border-gray-100 dark:border-gray-700 overflow-hidden">
                        <img src={item.image} alt={item.name} className="w-full h-32 object-cover" />
                        
                        <div className="absolute top-2 right-2 flex gap-1">
                            <div className={`text-[10px] font-bold px-2 py-1 rounded-full border shadow-sm ${getExpiryColor(item.expiryDays)}`}>
                                余 {item.expiryDays} 天
                            </div>
                        </div>

                        <div className="p-4">
                            <div className="flex justify-between items-start mb-1">
                                <h3 className="font-bold text-gray-800 dark:text-gray-100">{item.name}</h3>
                                <span className="text-xs text-gray-500 bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded">{item.quantity}</span>
                            </div>
                            <p className="text-xs text-gray-400 mb-3">{item.category}</p>
                            
                            <div className="flex gap-2">
                                <button className="flex-1 text-xs bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 py-1.5 rounded font-bold hover:bg-brand-100 transition-colors">
                                    食谱
                                </button>
                                <button className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors">
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Pantry;