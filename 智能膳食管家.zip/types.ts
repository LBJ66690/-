import React from 'react';

export interface User {
  id: string;
  name: string;
  avatar: string;
  weight: number;
  height: number;
  goal: 'LOSE_WEIGHT' | 'GAIN_MUSCLE' | 'MAINTAIN';
  allergies: string[];
}

export interface Recipe {
  id: string;
  title: string;
  image: string;
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  time: number; // minutes
  tags: string[];
  description: string;
  ingredients: { name: string; amount: string }[];
  steps: string[];
  rating: number;
  reviews: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  action?: {
    type: 'UPDATE_PLAN' | 'REJECT_REQUEST';
    payload?: any;
    display?: React.ReactNode;
  };
}

export interface HealthInsight {
  id: string;
  type: 'HIGH_SODIUM' | 'WEIGHT_PLATEAU' | 'GOOD_PROGRESS';
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface PantryItem {
  id: string;
  name: string;
  category: 'PROTEIN' | 'VEG' | 'CARB' | 'SAUCE' | 'FRUIT';
  quantity: string;
  expiryDays: number;
  image?: string;
}