import React from 'react';
import { ArrowRight, Flame, Dumbbell, X } from 'lucide-react';
import { Recipe } from '../types';

interface PlanDiffCardProps {
  oldRecipe: Recipe;
  newRecipe: Recipe;
  date: string;
  mealType: string;
  reason: string;
  onConfirm: () => void;
  onReject?: () => void;
}

const PlanDiffCard: React.FC<PlanDiffCardProps> = ({ oldRecipe, newRecipe, date, mealType, reason, onConfirm, onReject }) => {
  // Simple diff calculation
  const calDiff = newRecipe.calories - oldRecipe.calories;
  const proteinDiff = newRecipe.protein - oldRecipe.protein;

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden w-full max-w-md mx-auto my-2 animate-fade-in-up">
      {/* Header with Reason Bubble */}
      <div className="bg-gradient-to-r from-brand-50 to-white p-3 border-b border-brand-100 flex items-start gap-3">
        <div className="bg-brand-100 p-1.5 rounded-full text-brand-600 mt-0.5">
            <Flame size={16} />
        </div>
        <div>
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">AI 建议 · {date} {mealType}</div>
            <p className="text-sm text-gray-800 leading-snug font-medium">"{reason}"</p>
        </div>
      </div>

      {/* Split View */}
      <div className="flex relative">
        {/* Old Plan */}
        <div className="w-1/2 p-4 bg-gray-50 opacity-70 border-r border-gray-200 group">
          <div className="text-xs text-gray-400 mb-2 font-bold">原计划</div>
          <img src={oldRecipe.image} className="w-full h-24 object-cover rounded-lg mb-2 grayscale group-hover:grayscale-0 transition-all" alt="old" />
          <div className="font-bold text-gray-600 line-through decoration-gray-400 decoration-2 text-sm truncate">{oldRecipe.title}</div>
          <div className="text-xs text-gray-400 mt-1">{oldRecipe.calories} kcal</div>
        </div>

        {/* Center Icons (Absolute) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
            <div className="bg-white shadow-md rounded-full p-1 border border-gray-100">
                <ArrowRight size={16} className="text-gray-400" />
            </div>
        </div>

        {/* New Plan */}
        <div className="w-1/2 p-4 bg-white">
          <div className="text-xs text-brand-500 mb-2 font-bold flex items-center gap-1">
            新建议 <span className="w-2 h-2 rounded-full bg-brand-500 animate-ping"></span>
          </div>
          <img src={newRecipe.image} className="w-full h-24 object-cover rounded-lg mb-2 shadow-md" alt="new" />
          <div className="font-bold text-brand-600 text-sm truncate">{newRecipe.title}</div>
          <div className="flex flex-wrap gap-1 mt-2">
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold border ${calDiff > 0 ? 'bg-orange-50 text-orange-600 border-orange-200' : 'bg-green-50 text-green-600 border-green-200'}`}>
               {calDiff > 0 ? '+' : ''}{calDiff} kcal
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-blue-50 text-blue-600 border border-blue-200">
               Prot {proteinDiff > 0 ? '+' : ''}{proteinDiff}g
            </span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="p-3 bg-gray-50 flex gap-3">
        <button 
            onClick={onReject}
            className="flex-1 py-2 rounded-lg border border-gray-200 text-gray-500 text-sm font-bold hover:bg-white hover:text-gray-700 transition-colors"
        >
            保留原样
        </button>
        <button 
            onClick={onConfirm}
            className="flex-1 py-2 rounded-lg bg-brand-500 text-white text-sm font-bold shadow-lg shadow-brand-200 hover:bg-brand-600 transition-all"
        >
            确认修改
        </button>
      </div>
    </div>
  );
};

export default PlanDiffCard;