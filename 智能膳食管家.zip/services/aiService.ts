// Zhipu AI Service implementation
const API_KEY = "559d293e05b849ddbc0c164286e8eb37.fRgIBufU5AoTUAc3";

// Helper to base64url encode
const base64UrlEncode = (str: string): string => {
  return btoa(str)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
};

// Helper to generate JWT for Zhipu AI
// Note: In production, this should be done on the backend to keep the API SECRET secure.
const generateToken = async (apiKey: string): Promise<string> => {
  const [id, secret] = apiKey.split('.');
  if (!id || !secret) throw new Error('Invalid API Key format');

  const now = Date.now();
  const header = {
    alg: 'HS256',
    sign_type: 'SIGN'
  };
  
  const payload = {
    api_key: id,
    exp: now + 3600 * 1000, // 1 hour expiration
    timestamp: now
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payload));
  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const data = encoder.encode(dataToSign);

  const key = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign('HMAC', key, data);
  // Convert ArrayBuffer to binary string properly for btoa
  const signatureArray = Array.from(new Uint8Array(signature));
  const signatureString = signatureArray.map(byte => String.fromCharCode(byte)).join('');
  const encodedSignature = base64UrlEncode(signatureString);

  return `${encodedHeader}.${encodedPayload}.${encodedSignature}`;
};

export const streamChatResponse = async (
  userMessage: string,
  onChunk: (chunk: string) => void,
  onComplete: (fullMessage: string, action?: any) => void
) => {
  try {
    const token = await generateToken(API_KEY);
    
    // Construct messages context
    // In a real app, you might want to pass previous history here
    const messages = [
      { role: "system", content: "你是一个专业的智能膳食管家，负责根据用户的健康数据和偏好提供建议。请用亲切、专业的语气回答。如果用户需要修改食谱，请以JSON格式输出action。" },
      { role: "user", content: userMessage }
    ];

    const response = await fetch("https://open.bigmodel.cn/api/paas/v4/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        "Accept": "text/event-stream"
      },
      body: JSON.stringify({
        model: "glm-4.7-flash",
        messages: messages,
        thinking: {
          type: "enabled"
        },
        max_tokens: 65536,
        temperature: 1.0,
        stream: true
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("API Error:", errorText);
      onChunk(`(连接错误: ${response.status} - 请检查控制台)`);
      onComplete(`(连接错误: ${response.status})`, null);
      return;
    }

    if (!response.body) return;

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      buffer += chunk;
      
      const lines = buffer.split('\n');
      // Keep the last line in buffer if it's incomplete
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (line.trim() === "") continue;
        if (line.trim() === "data: [DONE]") continue;
        
        if (line.startsWith("data: ")) {
          try {
            const jsonStr = line.slice(6);
            const json = JSON.parse(jsonStr);
            const content = json.choices[0]?.delta?.content || "";
            
            // Check for reasoning_content (Thinking model feature) if available
            // const reasoning = json.choices[0]?.delta?.reasoning_content;
            
            if (content) {
              fullText += content;
              onChunk(fullText);
            }
          } catch (e) {
            console.warn("Error parsing SSE line", e);
          }
        }
      }
    }

    // Attempt to extract structured action from the full text (Simulation for the demo)
    // Real logic: You might ask the LLM to output specific JSON block and regex parse it here
    let action = null;
    if (fullText.includes("UPDATE") || fullText.includes("adjust") || (userMessage.includes("换") && fullText.includes("牛肉面"))) {
       // Mock parsing a specific action if the LLM suggests it, 
       // or you can instruct the LLM in system prompt to output a specific XML/JSON block
       // For this demo, we keep the previous 'beef noodle' trigger logic but applied to the real text if relevant,
       // or just return null to let the text speak for itself. 
       // To preserve the demo's "Update Plan" UI feature:
       if (userMessage.includes("游泳") || userMessage.includes("牛肉面")) {
           action = {
            type: 'UPDATE_PLAN',
            payload: {
                date: '2024-05-22',
                meal: 'LUNCH',
                oldRecipeId: 'r2',
                newRecipe: {
                    id: 'r4',
                    title: '经典红烧牛肉面',
                    image: 'https://picsum.photos/id/225/400/300',
                    time: 120,
                    calories: 650
                }
            }
           }
       }
    }

    onComplete(fullText, action);

  } catch (error) {
    console.error("Stream Error:", error);
    onChunk("(发生错误，请稍后重试)");
    onComplete("(发生错误)", null);
  }
};