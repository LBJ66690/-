import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  max?: number;
  interactive?: boolean;
  size?: number;
  onRate?: (rating: number) => void;
}

const StarRating: React.FC<StarRatingProps> = ({ 
  rating, 
  max = 5, 
  interactive = false, 
  size = 16,
  onRate 
}) => {
  const [hoverRating, setHoverRating] = React.useState(0);

  return (
    <div className="flex gap-0.5">
      {[...Array(max)].map((_, i) => {
        const starValue = i + 1;
        const isFilled = interactive 
          ? starValue <= (hoverRating || rating)
          : starValue <= rating;
        
        return (
          <button
            key={i}
            type="button"
            disabled={!interactive}
            onClick={() => interactive && onRate && onRate(starValue)}
            onMouseEnter={() => interactive && setHoverRating(starValue)}
            onMouseLeave={() => interactive && setHoverRating(0)}
            className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform`}
          >
            <Star 
              size={size} 
              className={`${
                isFilled 
                  ? 'fill-yellow-400 text-yellow-400' 
                  : 'fill-transparent text-gray-300'
              } transition-colors`} 
            />
          </button>
        );
      })}
    </div>
  );
};

export default StarRating;