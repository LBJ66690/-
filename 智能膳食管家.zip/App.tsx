import React, { useState, useEffect } from 'react';
import { 
  HashRouter as Router, 
  Routes, 
  Route, 
  Navigate, 
  useNavigate, 
  useLocation 
} from 'react-router-dom';
import { 
  LayoutDashboard, 
  Utensils, 
  User as UserIcon, 
  Search, 
  Bell, 
  Settings, 
  LogOut,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Plus,
  Heart,
  Calendar,
  Activity,
  Award,
  Target,
  ShoppingBag,
  PieChart as PieChartIcon,
  Flame,
  Droplets
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, PieChart, Pie, Cell } from 'recharts';

import { MOCK_RECIPES, MOCK_USER, MOCK_INSIGHTS } from './constants';
import { getHealthStats, getWeightHistory } from './services/mockService';
import ChatInterface from './components/ChatInterface';
import RecipeCard from './components/RecipeCard';
import { Recipe } from './types';

// --- Components for Pages ---

// 1. Login Page
const Login = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ user: '', pass: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(isLogin) {
        localStorage.setItem('auth', 'true');
        navigate('/');
    } else {
        // Mock register flow to onboarding
        localStorage.setItem('auth', 'true');
        navigate('/onboarding');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-400 to-secondary-500 flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl flex w-full max-w-4xl overflow-hidden min-h-[500px]">
        {/* Left Panel */}
        <div className="hidden md:flex flex-col justify-center items-center w-1/2 bg-brand-50 p-10 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">欢迎回来</h2>
          <p className="text-gray-600 mb-8">
            立即登录，开启您的{isLogin ? '智能膳食' : '健康生活'}之旅！
          </p>
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="px-8 py-2 border-2 border-brand-500 text-brand-500 rounded-full hover:bg-brand-50 transition-colors font-medium"
          >
            {isLogin ? '去注册' : '去登录'}
          </button>
        </div>

        {/* Right Panel (Form) */}
        <div className="w-full md:w-1/2 p-10 flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            {isLogin ? '登录账号' : '创建账号'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">用户名/邮箱</label>
              <input 
                type="text" 
                value={formData.user}
                onChange={e => setFormData({...formData, user: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-brand-400 focus:outline-none transition-all"
                placeholder={isLogin ? "Jim" : "例如: jim@example.com"}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">密码</label>
              <input 
                type="password" 
                value={formData.pass}
                onChange={e => setFormData({...formData, pass: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-brand-400 focus:outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-gradient-to-r from-brand-500 to-brand-600 text-white py-3 rounded-lg font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all"
            >
              {isLogin ? '登录' : '注册'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// 2. Onboarding (Simplified Wizard)
const Onboarding = () => {
    const navigate = useNavigate();
    const [step, setStep] = useState(1);

    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-8">
                <div className="mb-8 flex justify-center space-x-2">
                    {[1, 2, 3].map(i => (
                        <div key={i} className={`h-2 rounded-full transition-all ${step >= i ? 'w-8 bg-brand-500' : 'w-2 bg-gray-200'}`} />
                    ))}
                </div>
                
                {step === 1 && (
                    <div className="text-center animate-fade-in">
                        <h2 className="text-2xl font-bold mb-6">您的当前体重是？</h2>
                        <div className="text-5xl font-bold text-brand-600 mb-8">60 <span className="text-xl text-gray-400">kg</span></div>
                        <input type="range" min="40" max="120" defaultValue="60" className="w-full accent-brand-500 mb-8" />
                        <button onClick={() => setStep(2)} className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold">下一步</button>
                    </div>
                )}

                {step === 2 && (
                    <div className="text-center animate-fade-in">
                        <h2 className="text-2xl font-bold mb-6">您的饮食偏好？</h2>
                        <div className="grid grid-cols-2 gap-4 mb-8">
                            {['中式', '西式', '高蛋白', '低碳水'].map(t => (
                                <button key={t} className="border-2 border-gray-100 hover:border-brand-500 hover:text-brand-500 py-3 rounded-xl font-medium transition-colors focus:border-brand-500 focus:text-brand-500">{t}</button>
                            ))}
                        </div>
                        <button onClick={() => setStep(3)} className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold">下一步</button>
                    </div>
                )}

                 {step === 3 && (
                    <div className="text-center animate-fade-in">
                        <h2 className="text-2xl font-bold mb-4">分析完成！</h2>
                        <p className="text-gray-500 mb-8">AI 已为您生成个性化膳食档案。</p>
                        <div className="bg-green-50 text-green-700 p-4 rounded-xl mb-8 flex items-center justify-center gap-2">
                            <Sparkles size={20} />
                            <span>推荐每日摄入: 1800 kcal</span>
                        </div>
                        <button onClick={() => navigate('/')} className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold">进入首页</button>
                    </div>
                )}
            </div>
        </div>
    )
}

// 3. Main Dashboard (Home)
const Home = () => {
  const navigate = useNavigate();
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Banner */}
      <div className="relative rounded-2xl overflow-hidden bg-gray-900 text-white h-64 shadow-lg group">
        <img 
          src="https://picsum.photos/id/493/1000/400" 
          alt="Banner" 
          className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" 
        />
        <div className="absolute inset-0 flex flex-col justify-center px-8">
          <span className="bg-brand-500 text-xs font-bold px-2 py-1 rounded w-fit mb-3">今日公告</span>
          <h2 className="text-3xl font-bold mb-2">网络维护与月度更新</h2>
          <p className="text-gray-200 max-w-lg mb-6">为了提供更流畅的AI对话体验，我们将于本周日进行系统升级...</p>
          <button className="bg-white text-gray-900 px-6 py-2 rounded-full font-bold w-fit hover:bg-brand-50 transition-colors">查看详情</button>
        </div>
      </div>

      {/* Recommendations */}
      <div>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
              <Sparkles className="text-brand-500" size={20} />
              智能推荐食谱
            </h3>
            <p className="text-sm text-gray-500 mt-1">{new Date().toLocaleDateString()} · 基于您的健康数据</p>
          </div>
          <button className="text-brand-600 text-sm font-medium hover:underline">查看更多</button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {MOCK_RECIPES.map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} onClick={(id) => navigate(`/recipe/${id}`)} />
          ))}
        </div>
      </div>

      {/* Community Feed Preview */}
      <div>
        <h3 className="text-xl font-bold text-gray-800 mb-4">美食社区</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1,2,3,4].map(i => (
                <div key={i} className="aspect-square rounded-xl overflow-hidden relative group cursor-pointer">
                    <img src={`https://picsum.photos/id/${300+i}/300/300`} className="w-full h-full object-cover" alt="Community" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white font-medium">
                        <Heart className="mr-1 fill-white" size={16} /> 1.2k
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

// 4. Meal Plan Page (New)
const MealPlan = () => {
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const meals = [
      { id: 'breakfast', name: '早餐', icon: <Droplets size={16} className="text-blue-400" /> }, 
      { id: 'lunch', name: '午餐', icon: <Flame size={16} className="text-orange-400" /> }, 
      { id: 'dinner', name: '晚餐', icon: <Utensils size={16} className="text-indigo-400" /> }
  ];

  // Helper to get random recipe
  const getRandomRecipe = (seed: number) => MOCK_RECIPES[seed % MOCK_RECIPES.length];

  return (
      <div className="h-full flex flex-col gap-6 animate-fade-in">
          {/* Header */}
          <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                  <div className="bg-brand-50 p-2 rounded-lg">
                      <Calendar className="text-brand-500" size={24} />
                  </div>
                  <div>
                      <h1 className="text-xl font-bold text-gray-800">本周膳食计划</h1>
                      <p className="text-sm text-gray-500">2024.05.20 - 2024.05.26</p>
                  </div>
              </div>
              <div className="flex gap-2">
                  <button className="p-2 hover:bg-gray-100 rounded-lg"><ChevronLeft size={20} /></button>
                  <button className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-bold text-gray-700">今天</button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg"><ChevronRight size={20} /></button>
              </div>
              <button className="hidden md:flex items-center gap-2 bg-brand-500 text-white px-4 py-2 rounded-lg font-bold shadow hover:bg-brand-600 transition-colors">
                  <Sparkles size={16} />
                  AI 生成下周计划
              </button>
          </div>

          <div className="flex flex-col lg:flex-row gap-6 h-full min-h-[600px]">
              {/* Calendar Grid */}
              <div className="flex-1 bg-white rounded-2xl shadow-sm p-4 overflow-x-auto">
                  <div className="min-w-[800px] h-full flex flex-col">
                      {/* Days Header */}
                      <div className="grid grid-cols-8 gap-4 mb-4 pb-2 border-b border-gray-100">
                          <div className="font-bold text-gray-400 text-sm flex items-end">时段</div>
                          {days.map((day, i) => (
                              <div key={day} className="text-center">
                                  <div className="text-xs text-gray-400">5/{20+i}</div>
                                  <div className={`font-bold ${i===2 ? 'text-brand-500' : 'text-gray-700'}`}>{day}</div>
                              </div>
                          ))}
                      </div>

                      {/* Meal Rows */}
                      <div className="flex-1 space-y-4">
                          {meals.map((meal) => (
                              <div key={meal.id} className="grid grid-cols-8 gap-4 min-h-[140px]">
                                  {/* Row Label */}
                                  <div className="flex flex-col justify-center items-center gap-2 text-gray-500 bg-gray-50/50 rounded-xl">
                                      {meal.icon}
                                      <span className="text-sm font-bold writing-vertical">{meal.name}</span>
                                  </div>
                                  
                                  {/* Day Slots */}
                                  {days.map((_, dayIdx) => {
                                      const recipe = getRandomRecipe(dayIdx + meal.id.length);
                                      return (
                                          <div key={dayIdx} className="relative group bg-gray-50 rounded-xl p-2 border border-transparent hover:border-brand-200 hover:shadow-md transition-all cursor-pointer">
                                              <div className="aspect-video rounded-lg overflow-hidden mb-2">
                                                  <img src={recipe.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform" alt="meal" />
                                              </div>
                                              <div className="text-xs font-bold text-gray-800 line-clamp-1">{recipe.title}</div>
                                              <div className="text-[10px] text-gray-500">{recipe.calories} kcal</div>
                                              <button className="absolute top-1 right-1 bg-white rounded-full p-1 opacity-0 group-hover:opacity-100 shadow-sm">
                                                  <Plus size={12} className="text-brand-500" />
                                              </button>
                                          </div>
                                      );
                                  })}
                              </div>
                          ))}
                      </div>
                  </div>
              </div>

              {/* Sidebar Stats */}
              <div className="w-full lg:w-80 flex flex-col gap-6">
                  {/* Shopping List Card */}
                  <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
                      <div className="flex justify-between items-center mb-4">
                          <h3 className="font-bold text-lg flex items-center gap-2">
                              <ShoppingBag size={20} /> 采购清单
                          </h3>
                          <span className="bg-white/20 px-2 py-1 rounded text-xs">12 项</span>
                      </div>
                      <div className="space-y-2 mb-4 text-sm text-indigo-100">
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>鸡胸肉</span>
                              <span>500g</span>
                          </div>
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>西兰花</span>
                              <span>2 颗</span>
                          </div>
                          <div className="flex justify-between border-b border-white/10 pb-1">
                              <span>全麦面包</span>
                              <span>1 袋</span>
                          </div>
                      </div>
                      <button className="w-full bg-white text-indigo-600 py-2 rounded-lg font-bold text-sm hover:bg-indigo-50 transition-colors">
                          查看全部
                      </button>
                  </div>

                  {/* Daily Nutrition */}
                  <div className="bg-white rounded-2xl p-6 shadow-sm flex-1">
                      <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                          <PieChartIcon className="text-brand-500" size={18} /> 今日营养概览
                      </h3>
                      <div className="h-48 relative flex items-center justify-center">
                          <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                  <Pie
                                      data={[
                                          { name: '碳水', value: 45 },
                                          { name: '蛋白质', value: 30 },
                                          { name: '脂肪', value: 25 },
                                      ]}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={40}
                                      outerRadius={70}
                                      paddingAngle={5}
                                      dataKey="value"
                                  >
                                      <Cell fill="#f97316" /> {/* Orange */}
                                      <Cell fill="#3b82f6" /> {/* Blue */}
                                      <Cell fill="#fbbf24" /> {/* Yellow */}
                                  </Pie>
                              </PieChart>
                          </ResponsiveContainer>
                          <div className="absolute text-center">
                              <div className="text-2xl font-bold text-gray-800">1850</div>
                              <div className="text-xs text-gray-400">kcal</div>
                          </div>
                      </div>
                      <div className="space-y-3 mt-2">
                          <div className="flex items-center gap-3 text-sm">
                              <div className="w-3 h-3 rounded-full bg-brand-500"></div>
                              <span className="text-gray-500 flex-1">碳水化合物</span>
                              <span className="font-bold">45%</span>
                          </div>
                          <div className="flex items-center gap-3 text-sm">
                              <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                              <span className="text-gray-500 flex-1">蛋白质</span>
                              <span className="font-bold">30%</span>
                          </div>
                          <div className="flex items-center gap-3 text-sm">
                              <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                              <span className="text-gray-500 flex-1">脂肪</span>
                              <span className="font-bold">25%</span>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  );
};


// 5. Recipe Detail
const RecipeDetail = () => {
    const navigate = useNavigate();
    const recipe = MOCK_RECIPES[0]; // Simplification for demo

    return (
        <div className="animate-fade-in pb-10">
            <button onClick={() => navigate(-1)} className="mb-4 text-gray-500 hover:text-gray-900 flex items-center gap-1">
                <ChevronLeft size={20} /> 返回
            </button>
            
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="h-80 relative">
                    <img src={recipe.image} className="w-full h-full object-cover" alt={recipe.title} />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent p-6 text-white">
                        <h1 className="text-3xl font-bold mb-2">{recipe.title}</h1>
                        <div className="flex items-center gap-4 text-sm opacity-90">
                            <span className="bg-brand-500 px-2 py-0.5 rounded text-xs">AI 严选</span>
                            <span>{recipe.rating} 分</span>
                            <span>{recipe.reviews} 评论</span>
                        </div>
                    </div>
                </div>

                <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left: Info */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Ingredients */}
                        <section>
                            <h3 className="text-lg font-bold text-gray-800 mb-4 border-l-4 border-brand-500 pl-3">食材清单</h3>
                            <div className="grid grid-cols-2 gap-4">
                                {recipe.ingredients.map((ing, idx) => (
                                    <div key={idx} className="flex justify-between p-3 bg-gray-50 rounded-lg">
                                        <span className="text-gray-700">{ing.name}</span>
                                        <span className="font-medium text-gray-900">{ing.amount}</span>
                                    </div>
                                ))}
                            </div>
                        </section>

                         {/* Steps */}
                         <section>
                            <h3 className="text-lg font-bold text-gray-800 mb-4 border-l-4 border-brand-500 pl-3">制作步骤</h3>
                            <div className="space-y-4">
                                {recipe.steps.map((step, idx) => (
                                    <div key={idx} className="flex gap-4">
                                        <div className="w-8 h-8 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center font-bold flex-shrink-0">
                                            {idx + 1}
                                        </div>
                                        <p className="text-gray-600 mt-1">{step}</p>
                                    </div>
                                ))}
                            </div>
                        </section>
                        
                        {/* Comments */}
                        <section className="pt-6 border-t border-gray-100">
                             <h3 className="text-lg font-bold text-gray-800 mb-4">评论 (2)</h3>
                             <div className="space-y-4">
                                <div className="flex gap-3">
                                    <img src="https://picsum.photos/id/65/50/50" className="w-10 h-10 rounded-full" alt="User" />
                                    <div className="bg-gray-50 p-3 rounded-xl flex-1">
                                        <div className="flex justify-between mb-1">
                                            <span className="font-bold text-sm">Alice</span>
                                            <span className="text-xs text-gray-400">2小时前</span>
                                        </div>
                                        <p className="text-sm text-gray-600">真的很好吃！减脂期也能吃甜品太幸福了。</p>
                                    </div>
                                </div>
                             </div>
                        </section>
                    </div>

                    {/* Right: Nutrition */}
                    <div className="space-y-6">
                        <div className="bg-white border border-gray-100 p-5 rounded-xl shadow-sm">
                            <h3 className="font-bold text-gray-800 mb-4">营养信息 (每份)</h3>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-500 text-sm">热量</span>
                                    <span className="font-bold text-brand-600">{recipe.calories} kcal</span>
                                </div>
                                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                                    <div className="h-full bg-brand-500 w-3/4"></div>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-2">
                                    <div className="bg-blue-50 p-2 rounded">
                                        <div className="text-blue-500 font-bold">{recipe.protein}g</div>
                                        <div className="text-gray-400">蛋白</div>
                                    </div>
                                    <div className="bg-yellow-50 p-2 rounded">
                                        <div className="text-yellow-500 font-bold">{recipe.fat}g</div>
                                        <div className="text-gray-400">脂肪</div>
                                    </div>
                                    <div className="bg-green-50 p-2 rounded">
                                        <div className="text-green-500 font-bold">{recipe.carbs}g</div>
                                        <div className="text-gray-400">碳水</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <button className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-brand-200 hover:shadow-xl hover:bg-brand-600 transition-all">
                            添加到今日饮食
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// 6. User Profile (Redesigned)
const Profile = () => {
    const [activeTab, setActiveTab] = useState<'overview' | 'health' | 'prefs'>('overview');
    const stats = getHealthStats();
    const weightHistory = getWeightHistory();

    const tabs = [
        { id: 'overview', label: '概览', icon: <LayoutDashboard size={18} /> },
        { id: 'health', label: '健康数据', icon: <Activity size={18} /> },
        { id: 'prefs', label: '偏好设置', icon: <Settings size={18} /> },
    ];

    return (
        <div className="space-y-6 animate-fade-in pb-10">
            {/* Hero Header */}
            <div className="relative bg-gradient-to-r from-brand-600 to-brand-400 rounded-3xl p-8 text-white shadow-xl overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl"></div>
                
                <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
                    <div className="relative">
                        <img src={MOCK_USER.avatar} className="w-24 h-24 rounded-full border-4 border-white/30 shadow-lg" alt="Avatar" />
                        <div className="absolute bottom-0 right-0 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-0.5 rounded-full border border-white">Lv. 5</div>
                    </div>
                    <div className="text-center md:text-left flex-1">
                        <h1 className="text-3xl font-bold mb-1">{MOCK_USER.name}</h1>
                        <p className="text-brand-100 text-sm mb-4 flex items-center justify-center md:justify-start gap-2">
                           <Target size={16} /> 目标: 增肌 · 已坚持 12 天
                        </p>
                        <div className="flex gap-4 justify-center md:justify-start">
                             <div className="bg-white/20 px-4 py-2 rounded-xl backdrop-blur-sm text-center">
                                 <div className="text-xl font-bold">60.0</div>
                                 <div className="text-[10px] text-brand-100 uppercase">Current Kg</div>
                             </div>
                             <div className="bg-white/20 px-4 py-2 rounded-xl backdrop-blur-sm text-center">
                                 <div className="text-xl font-bold">18.5</div>
                                 <div className="text-[10px] text-brand-100 uppercase">BMI</div>
                             </div>
                             <div className="bg-white/20 px-4 py-2 rounded-xl backdrop-blur-sm text-center">
                                 <div className="text-xl font-bold">14</div>
                                 <div className="text-[10px] text-brand-100 uppercase">Streak</div>
                             </div>
                        </div>
                    </div>
                    <button className="bg-white text-brand-600 px-4 py-2 rounded-full font-bold shadow hover:bg-brand-50 transition-colors">
                        编辑资料
                    </button>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex bg-white p-1 rounded-xl shadow-sm w-fit mx-auto md:mx-0">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`flex items-center gap-2 px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                            activeTab === tab.id 
                            ? 'bg-brand-50 text-brand-600 shadow-sm' 
                            : 'text-gray-500 hover:bg-gray-50'
                        }`}
                    >
                        {tab.icon} {tab.label}
                    </button>
                ))}
            </div>

            {/* Content Areas */}
            {activeTab === 'overview' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Weight Chart */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                        <h3 className="font-bold text-gray-800 mb-6 flex justify-between items-center">
                            体重趋势
                            <span className="text-xs font-normal text-green-600 bg-green-50 px-2 py-1 rounded flex items-center gap-1">
                                <Activity size={12} /> -2.1kg 本月
                            </span>
                        </h3>
                        <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={weightHistory}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                                    <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                                    <YAxis axisLine={false} tickLine={false} domain={['dataMin - 1', 'dataMax + 1']} tick={{fill: '#9ca3af', fontSize: 12}} />
                                    <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                                    <Line type="monotone" dataKey="weight" stroke="#f97316" strokeWidth={3} dot={{r: 4, fill: '#f97316', strokeWidth: 2, stroke: '#fff'}} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* Recent Achievements */}
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                        <h3 className="font-bold text-gray-800 mb-6">最近成就</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-yellow-50 rounded-xl flex items-center gap-3 border border-yellow-100">
                                <div className="p-2 bg-yellow-100 rounded-full text-yellow-600"><Award size={20} /></div>
                                <div>
                                    <div className="font-bold text-gray-800 text-sm">早起鸟</div>
                                    <div className="text-xs text-gray-500">连续7天记录早餐</div>
                                </div>
                            </div>
                            <div className="p-4 bg-blue-50 rounded-xl flex items-center gap-3 border border-blue-100">
                                <div className="p-2 bg-blue-100 rounded-full text-blue-600"><Droplets size={20} /></div>
                                <div>
                                    <div className="font-bold text-gray-800 text-sm">补水达人</div>
                                    <div className="text-xs text-gray-500">日均喝水2L</div>
                                </div>
                            </div>
                            <div className="p-4 bg-purple-50 rounded-xl flex items-center gap-3 border border-purple-100">
                                <div className="p-2 bg-purple-100 rounded-full text-purple-600"><Flame size={20} /></div>
                                <div>
                                    <div className="font-bold text-gray-800 text-sm">燃烧卡路里</div>
                                    <div className="text-xs text-gray-500">消耗 5000 kcal</div>
                                </div>
                            </div>
                             <div className="p-4 bg-gray-50 rounded-xl flex items-center gap-3 border border-gray-100 border-dashed justify-center text-gray-400">
                                <span className="text-xs">更多成就待解锁...</span>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'health' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
                     <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                        <h3 className="font-bold text-gray-800 mb-2">营养摄入雷达</h3>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={stats}>
                                    <PolarGrid stroke="#e5e7eb" />
                                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#6b7280', fontSize: 12 }} />
                                    <PolarRadiusAxis angle={30} domain={[0, 150]} tick={false} axisLine={false} />
                                    <Radar name="User" dataKey="A" stroke="#f97316" fill="#f97316" fillOpacity={0.4} />
                                </RadarChart>
                            </ResponsiveContainer>
                        </div>
                     </div>
                     <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                        <h3 className="font-bold text-gray-800 mb-4">详细指标</h3>
                        <div className="space-y-4">
                            {[
                                { label: '基础代谢率 (BMR)', val: '1450 kcal', status: '正常' },
                                { label: '体脂率', val: '22%', status: '偏高' },
                                { label: '肌肉量', val: '42.5 kg', status: '优秀' },
                                { label: '内脏脂肪等级', val: '4', status: '正常' },
                            ].map((item, i) => (
                                <div key={i} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg transition-colors border-b border-gray-50 last:border-0">
                                    <span className="text-gray-600 text-sm">{item.label}</span>
                                    <div className="flex items-center gap-3">
                                        <span className="font-bold text-gray-800">{item.val}</span>
                                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                                            item.status === '正常' || item.status === '优秀' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'
                                        }`}>{item.status}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                     </div>
                </div>
            )}

            {activeTab === 'prefs' && (
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 animate-fade-in">
                    <h3 className="font-bold text-gray-800 mb-6">饮食偏好设置</h3>
                    
                    <div className="space-y-6">
                        <div>
                            <label className="text-sm font-medium text-gray-500 mb-3 block">忌口 / 过敏源</label>
                            <div className="flex flex-wrap gap-2">
                                {['花生', '海鲜', '香菜', '芒果', '酒精'].map(tag => (
                                    <button key={tag} className={`px-4 py-2 rounded-full text-sm border transition-colors ${
                                        MOCK_USER.allergies.includes(tag) 
                                        ? 'bg-red-50 border-red-200 text-red-600' 
                                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                                    }`}>
                                        {tag}
                                    </button>
                                ))}
                                <button className="px-4 py-2 rounded-full text-sm border border-dashed border-gray-300 text-gray-400 hover:text-gray-600 hover:border-gray-400">
                                    + 添加
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium text-gray-500 mb-3 block">菜系偏好</label>
                            <div className="flex flex-wrap gap-2">
                                {['川菜', '粤菜', '日式', '地中海', '轻食'].map(tag => (
                                    <button key={tag} className="px-4 py-2 rounded-full text-sm border border-gray-200 text-gray-600 hover:bg-gray-50">
                                        {tag}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="pt-4 border-t border-gray-100 flex justify-end">
                            <button className="bg-brand-500 text-white px-6 py-2 rounded-lg font-bold hover:bg-brand-600 shadow-md">保存设置</button>
                        </div>
                    </div>
                 </div>
            )}
        </div>
    );
}

// --- Layout Shell ---
const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [showChat, setShowChat] = useState(false);
  const [notifications] = useState(MOCK_INSIGHTS);
  const [showNotif, setShowNotif] = useState(false);

  const isActive = (path: string) => location.pathname === path ? 'bg-brand-50 text-brand-600' : 'text-gray-500 hover:bg-gray-50';

  return (
    <div className="flex min-h-screen bg-gray-50 font-sans">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-gray-100 fixed h-full z-10">
        <div className="p-8 flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center text-white font-bold text-xl">D</div>
            <h1 className="text-2xl font-bold text-gray-800 tracking-tight">Diet<span className="text-brand-500">Master</span></h1>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          <button onClick={() => navigate('/')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/')}`}>
            <LayoutDashboard size={20} /> 首页
          </button>
          <button onClick={() => navigate('/plan')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/plan')}`}>
            <Utensils size={20} /> 膳食计划
          </button>
          <button onClick={() => navigate('/profile')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/profile')}`}>
            <UserIcon size={20} /> 个人中心
          </button>
        </nav>

        <div className="p-4 border-t border-gray-100">
           <button onClick={() => { localStorage.clear(); navigate('/login'); }} className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-xl transition-all font-medium">
             <LogOut size={20} /> 退出登录
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="bg-white/80 backdrop-blur-md sticky top-0 z-20 border-b border-gray-100 px-8 py-4 flex justify-between items-center">
            <div className="flex-1 max-w-md">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input 
                        type="text" 
                        placeholder="搜索菜谱、食材..." 
                        className="w-full bg-gray-100 pl-10 pr-4 py-2 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-brand-200 transition-all"
                    />
                </div>
            </div>

            <div className="flex items-center gap-6">
                {/* Notification Bell with Dropdown */}
                <div className="relative">
                    <button onClick={() => setShowNotif(!showNotif)} className="relative p-2 hover:bg-gray-100 rounded-full transition-colors">
                        <Bell size={20} className="text-gray-600" />
                        {notifications.some(n => !n.isRead) && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>}
                    </button>
                    
                    {showNotif && (
                        <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden animate-fade-in-up">
                            <div className="p-3 bg-gray-50 border-b border-gray-100 font-bold text-gray-700 text-sm">健康预警 (Flink实时)</div>
                            {notifications.map(n => (
                                <div key={n.id} className="p-4 hover:bg-brand-50 transition-colors border-b border-gray-50 last:border-0 cursor-pointer">
                                    <div className="flex items-start gap-3">
                                        <div className="bg-red-100 text-red-500 p-1.5 rounded-full mt-0.5">
                                            <Sparkles size={14} />
                                        </div>
                                        <div>
                                            <p className="text-sm text-gray-800 leading-snug">{n.message}</p>
                                            <p className="text-xs text-gray-400 mt-1">{n.timestamp}</p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/profile')}>
                    <span className="text-sm font-bold text-gray-700 hidden md:block">{MOCK_USER.name}</span>
                    <img src={MOCK_USER.avatar} className="w-9 h-9 rounded-full border border-gray-200" alt="Avatar" />
                </div>
            </div>
        </header>

        {/* Page Content */}
        <div className="p-4 md:p-8 overflow-y-auto">
             <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/plan" element={<MealPlan />} />
                <Route path="/recipe/:id" element={<RecipeDetail />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="*" element={<Navigate to="/" />} />
             </Routes>
        </div>
      </main>

      {/* Floating Chat Button */}
      {!showChat && (
        <button 
            onClick={() => setShowChat(true)}
            className="fixed bottom-8 right-8 bg-brand-600 text-white p-4 rounded-full shadow-lg shadow-brand-500/40 hover:scale-110 transition-transform z-30 flex items-center gap-2 group"
        >
            <BotIcon />
            <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 whitespace-nowrap text-sm font-bold">智能管家</span>
        </button>
      )}

      {/* Chat Interface */}
      <ChatInterface isOpen={showChat} onClose={() => setShowChat(false)} />
    </div>
  );
};

// Simple icon wrapper
const BotIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 8V4H8"></path>
        <rect width="16" height="12" x="4" y="8" rx="2"></rect>
        <path d="M2 14h2"></path>
        <path d="M20 14h2"></path>
        <path d="M15 13v2"></path>
        <path d="M9 13v2"></path>
    </svg>
);

// Protected Route Wrapper
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    const isAuth = localStorage.getItem('auth');
    if (!isAuth) {
        return <Navigate to="/login" replace />;
    }
    return <>{children}</>;
};

// Main App Component
const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/*" element={
            <ProtectedRoute>
                <Layout />
            </ProtectedRoute>
        } />
      </Routes>
    </Router>
  );
};

export default App;