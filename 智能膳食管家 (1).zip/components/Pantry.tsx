import React, { useState } from 'react';
import { Search, RotateCcw, Sparkles, Minus, Plus, ChefHat, X, CheckCircle, ArrowRight, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';
import { MOCK_RECIPES } from '../constants'; // Using mock recipes for search results

interface Ingredient {
  ingredient_id: string;
  standard_name: string;
  category_id: 'meat' | 'veg' | 'dairy' | 'carb' | 'fruit' | 'seasoning';
  icon: string;
  default_unit: string;
}

interface PantryState {
  [id: string]: number; // quantity
}

const INGREDIENT_LIBRARY: Ingredient[] = [
  // Meat
  { ingredient_id: 'i1', standard_name: '鸡胸肉', category_id: 'meat', icon: '🍗', default_unit: 'g' },
  { ingredient_id: 'i2', standard_name: '牛肉', category_id: 'meat', icon: '🥩', default_unit: 'g' },
  { ingredient_id: 'i3', standard_name: '虾仁', category_id: 'meat', icon: '🍤', default_unit: '个' },
  { ingredient_id: 'i4', standard_name: '培根', category_id: 'meat', icon: '🥓', default_unit: '片' },
  // Veg
  { ingredient_id: 'i5', standard_name: '西兰花', category_id: 'veg', icon: '🥦', default_unit: '朵' },
  { ingredient_id: 'i6', standard_name: '胡萝卜', category_id: 'veg', icon: '🥕', default_unit: '根' },
  { ingredient_id: 'i7', standard_name: '番茄', category_id: 'veg', icon: '🍅', default_unit: '个' },
  { ingredient_id: 'i8', standard_name: '生菜', category_id: 'veg', icon: '🥬', default_unit: '棵' },
  { ingredient_id: 'i9', standard_name: '洋葱', category_id: 'veg', icon: '🧅', default_unit: '个' },
  // Dairy & Egg
  { ingredient_id: 'i10', standard_name: '鸡蛋', category_id: 'dairy', icon: '🥚', default_unit: '个' },
  { ingredient_id: 'i11', standard_name: '牛奶', category_id: 'dairy', icon: '🥛', default_unit: '盒' },
  { ingredient_id: 'i12', standard_name: '芝士片', category_id: 'dairy', icon: '🧀', default_unit: '片' },
  // Carb
  { ingredient_id: 'i13', standard_name: '米饭', category_id: 'carb', icon: '🍚', default_unit: '碗' },
  { ingredient_id: 'i14', standard_name: '意面', category_id: 'carb', icon: '🍝', default_unit: '份' },
  { ingredient_id: 'i15', standard_name: '吐司', category_id: 'carb', icon: '🍞', default_unit: '片' },
];

const CATEGORIES = [
  { id: 'meat', name: '肉禽水产', color: 'text-red-500 bg-red-50' },
  { id: 'veg', name: '时令蔬菜', color: 'text-green-500 bg-green-50' },
  { id: 'dairy', name: '蛋奶豆制', color: 'text-yellow-500 bg-yellow-50' },
  { id: 'carb', name: '主食谷物', color: 'text-orange-500 bg-orange-50' },
];

const Pantry = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [pantry, setPantry] = useState<PantryState>({
    'i1': 2,
    'i5': 1,
    'i10': 6,
    'i7': 3 // Added Tomato for demo
  });
  
  // Selection State for Reverse Search
  const [selectedForSearch, setSelectedForSearch] = useState<Set<string>>(new Set());
  const [showResults, setShowResults] = useState(false);

  const handleUpdate = (id: string, delta: number) => {
    setPantry(prev => {
      const current = prev[id] || 0;
      const next = Math.max(0, current + delta);
      if (next === 0) {
        const { [id]: _, ...rest } = prev;
        // Also remove from selection if removed from pantry
        if (selectedForSearch.has(id)) {
            const newSet = new Set(selectedForSearch);
            newSet.delete(id);
            setSelectedForSearch(newSet);
        }
        return rest;
      }
      return { ...prev, [id]: next };
    });
  };

  const toggleItemSelection = (id: string) => {
      const newSet = new Set(selectedForSearch);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      setSelectedForSearch(newSet);
  };

  const addToPantry = (id: string) => {
      setPantry(prev => ({ ...prev, [id]: 1 }));
  };

  const handleClear = () => {
    if(confirm('确定要清空冰箱吗？')) {
        setPantry({});
        setSelectedForSearch(new Set());
        toast.success('冰箱已清空');
    }
  };

  const handleSearchRecipes = () => {
      setShowResults(true);
  };

  const filteredIngredients = INGREDIENT_LIBRARY.filter(i => 
    i.standard_name.includes(searchTerm)
  );

  return (
    <div className="animate-fade-in pb-40 max-w-5xl mx-auto space-y-8 relative">
      
      {/* Top Search Bar */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 flex gap-4 sticky top-4 z-30">
        <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
                type="text" 
                placeholder="搜索食材，如：牛肉..." 
                className="w-full pl-12 pr-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all dark:text-white"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />
        </div>
        <button 
            onClick={handleClear}
            className="px-6 py-2 border border-gray-200 dark:border-gray-600 rounded-xl hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition-colors flex items-center gap-2 text-gray-600 dark:text-gray-300 font-medium"
        >
            <RotateCcw size={18} /> 清空
        </button>
      </div>

      {/* Main Categories */}
      <div className="space-y-8">
        {CATEGORIES.map(cat => {
            const catItems = filteredIngredients.filter(i => i.category_id === cat.id);
            if (catItems.length === 0) return null;

            return (
                <div key={cat.id}>
                    <h3 className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-bold mb-4 ${cat.color}`}>
                        {cat.name}
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {catItems.map(item => {
                            const quantity = pantry[item.ingredient_id] || 0;
                            const isInPantry = quantity > 0;
                            const isSelected = selectedForSearch.has(item.ingredient_id);

                            return (
                                <div 
                                    key={item.ingredient_id}
                                    onClick={() => {
                                        if (isInPantry) toggleItemSelection(item.ingredient_id);
                                        else addToPantry(item.ingredient_id);
                                    }}
                                    className={`relative group rounded-2xl p-4 transition-all duration-300 border cursor-pointer select-none
                                        ${isInPantry
                                            ? isSelected 
                                                ? 'bg-brand-500 text-white shadow-lg scale-105 border-brand-500' // Selected for Search
                                                : 'bg-white dark:bg-gray-800 border-brand-200 shadow-sm' // In Pantry but not selected
                                            : 'bg-gray-50 dark:bg-gray-900 border-transparent opacity-60 hover:opacity-100 hover:bg-white hover:shadow-md' // Not in pantry
                                        }
                                    `}
                                >
                                    {/* Selection Checkbox Indicator */}
                                    {isInPantry && (
                                        <div className={`absolute top-2 right-2 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${isSelected ? 'border-white bg-white text-brand-500' : 'border-gray-300 bg-transparent'}`}>
                                            {isSelected && <CheckCircle size={14} fill="currentColor" className="text-brand-500" />}
                                        </div>
                                    )}

                                    <div className="flex flex-col items-center gap-2">
                                        <div className="text-4xl mb-1">{item.icon}</div>
                                        <div className={`font-bold ${isInPantry && isSelected ? 'text-white' : 'text-gray-700 dark:text-gray-300'}`}>
                                            {item.standard_name}
                                        </div>
                                    </div>

                                    {/* Quantity Control (Only show if in pantry and NOT in search selection mode to avoid conflict? Or allow both. Let's keep it simple: stop propagation for controls) */}
                                    {isInPantry && !isSelected && (
                                        <div className="mt-4 flex items-center justify-center gap-2 animate-fade-in">
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); handleUpdate(item.ingredient_id, -1); }}
                                                className="w-6 h-6 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600"
                                            >
                                                <Minus size={12} />
                                            </button>
                                            <span className="font-mono text-sm font-bold text-gray-500">
                                                {quantity}
                                            </span>
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); handleUpdate(item.ingredient_id, 1); }}
                                                className="w-6 h-6 rounded-full bg-brand-100 hover:bg-brand-200 flex items-center justify-center text-brand-600"
                                            >
                                                <Plus size={12} />
                                            </button>
                                        </div>
                                    )}
                                    
                                    {/* Selected State Text */}
                                    {isSelected && (
                                        <div className="mt-4 text-center text-xs font-bold text-white/90">
                                            已选用于烹饪
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            );
        })}
      </div>

      {/* Bottom Floating Action Bar */}
      <div className={`fixed bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-md border-t border-gray-200 z-40 transition-transform duration-300 transform ${selectedForSearch.size > 0 ? 'translate-y-0' : 'translate-y-full'}`}>
         <div className="max-w-4xl mx-auto flex items-center justify-between">
             <div className="flex items-center gap-4">
                 <div className="bg-brand-100 text-brand-600 w-10 h-10 rounded-full flex items-center justify-center font-bold">
                     {selectedForSearch.size}
                 </div>
                 <div>
                     <div className="font-bold text-gray-800">已选食材</div>
                     <div className="text-xs text-gray-500">准备大展身手了吗？</div>
                 </div>
             </div>
             
             <button 
                onClick={handleSearchRecipes}
                className="bg-gray-900 text-white px-8 py-3 rounded-xl shadow-xl flex items-center gap-2 font-bold hover:bg-gray-800 transition-colors"
             >
                 <Sparkles size={18} className="text-yellow-400" />
                 搜索能做的菜
             </button>
         </div>
      </div>

      {/* Results Drawer / Modal */}
      {showResults && (
          <div className="fixed inset-0 z-50 flex justify-end">
              <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setShowResults(false)}></div>
              <div className="relative w-full max-w-md bg-white dark:bg-gray-900 h-full shadow-2xl animate-fade-in-right overflow-y-auto">
                  <div className="p-6 sticky top-0 bg-white/95 dark:bg-gray-900/95 backdrop-blur z-10 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
                      <h2 className="text-xl font-bold flex items-center gap-2">
                          <ChefHat className="text-brand-500" /> 
                          推荐食谱
                      </h2>
                      <button onClick={() => setShowResults(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button>
                  </div>

                  <div className="p-6 space-y-8">
                      {/* Perfect Match */}
                      <section>
                          <h3 className="flex items-center gap-2 font-bold text-green-600 mb-4 bg-green-50 w-fit px-3 py-1 rounded-full text-sm">
                              <CheckCircle size={16} /> 完美匹配 (消耗库存)
                          </h3>
                          <div className="space-y-4">
                              {/* Mock Data */}
                              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                                  <div className="h-32 bg-gray-200 relative">
                                      <img src={MOCK_RECIPES[1].image} className="w-full h-full object-cover" alt="match" />
                                      <div className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur">
                                          消耗: 白玉菇, 火腿
                                      </div>
                                  </div>
                                  <div className="p-4">
                                      <h4 className="font-bold text-gray-800">{MOCK_RECIPES[1].title}</h4>
                                      <div className="text-xs text-gray-500 mt-1 mb-3">只需再加点 盐, 葱</div>
                                      <button className="w-full bg-brand-500 text-white py-2 rounded-lg text-sm font-bold">查看做法</button>
                                  </div>
                              </div>
                          </div>
                      </section>

                      {/* Missing One */}
                      <section>
                          <h3 className="flex items-center gap-2 font-bold text-orange-500 mb-4 bg-orange-50 w-fit px-3 py-1 rounded-full text-sm">
                              <ShoppingCart size={16} /> 只缺一味
                          </h3>
                          <div className="space-y-4">
                              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                                  <div className="h-32 bg-gray-200 relative">
                                      <img src={MOCK_RECIPES[0].image} className="w-full h-full object-cover" alt="match" />
                                  </div>
                                  <div className="p-4">
                                      <div className="flex justify-between items-start">
                                          <h4 className="font-bold text-gray-800">{MOCK_RECIPES[0].title}</h4>
                                          <span className="text-xs font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded">缺: 淡奶油</span>
                                      </div>
                                      <div className="mt-3 flex gap-2">
                                          <button className="flex-1 bg-gray-100 text-gray-600 py-2 rounded-lg text-xs font-bold hover:bg-gray-200">
                                              + 加淡奶油到清单
                                          </button>
                                          <button className="w-20 bg-brand-50 text-brand-600 border border-brand-200 py-2 rounded-lg text-xs font-bold">
                                              去烹饪
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

export default Pantry;