import React, { useState, useEffect } from 'react';
import { 
  HashRouter as Router, 
  Routes, 
  Route, 
  Navigate, 
  useNavigate, 
  useLocation 
} from 'react-router-dom';
import { 
  LayoutDashboard, Utensils, User as UserIcon, Search, Bell, LogOut, Sparkles, ShoppingBag, 
  FileText, ChefHat, Moon, Sun, Refrigerator, Settings as SettingsIcon, Heart, Users, Trophy,
  Bot as BotIcon
} from 'lucide-react';
import { Toaster } from 'sonner';

import { MOCK_RECIPES, MOCK_USER, MOCK_INSIGHTS } from './constants';
import ChatInterface from './components/ChatInterface';
import RecipeCard from './components/RecipeCard';
import AttributionModal from './components/AttributionModal';
import WeeklyReport from './components/WeeklyReport';
import Pantry from './components/Pantry';
import MealPlan from './components/MealPlan';
import RecipeDetail from './components/RecipeDetail'; 
import CookingMode from './components/CookingMode'; 
import Profile from './components/Profile';
import Favorites from './components/Favorites';
import Settings from './components/Settings';
import CategoryFilter from './components/CategoryFilter';
import CommunityFeed from './components/Community/CommunityFeed';
import ChallengeCenter from './components/Community/ChallengeCenter';

// --- Components for Pages ---
const Login = () => {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ user: '', pass: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('auth', 'true');
    navigate(isLogin ? '/' : '/onboarding');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-400 to-secondary-500 flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl flex w-full max-w-4xl overflow-hidden min-h-[500px]">
        {/* Left Panel */}
        <div className="hidden md:flex flex-col justify-center items-center w-1/2 bg-brand-50 p-10 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">欢迎回来</h2>
          <p className="text-gray-600 mb-8">
            立即登录，开启您的{isLogin ? '智能膳食' : '健康生活'}之旅！
          </p>
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="px-8 py-2 border-2 border-brand-500 text-brand-500 rounded-full hover:bg-brand-50 transition-colors font-medium"
          >
            {isLogin ? '去注册' : '去登录'}
          </button>
        </div>

        {/* Right Panel (Form) */}
        <div className="w-full md:w-1/2 p-10 flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
            {isLogin ? '登录账号' : '创建账号'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">用户名/邮箱</label>
              <input 
                type="text" 
                value={formData.user}
                onChange={e => setFormData({...formData, user: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-brand-400 focus:outline-none transition-all"
                placeholder={isLogin ? "Jim" : "例如: jim@example.com"}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">密码</label>
              <input 
                type="password" 
                value={formData.pass}
                onChange={e => setFormData({...formData, pass: e.target.value})}
                className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-brand-400 focus:outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-gradient-to-r from-brand-500 to-brand-600 text-white py-3 rounded-lg font-bold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all"
            >
              {isLogin ? '登录' : '注册'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

const Onboarding = () => {
    const navigate = useNavigate();
    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-8">
                 <div className="text-center">
                    <h2 className="text-2xl font-bold mb-4">初始化配置...</h2>
                    <button onClick={() => navigate('/')} className="w-full bg-brand-500 text-white py-3 rounded-xl font-bold">跳过 (演示模式)</button>
                 </div>
            </div>
        </div>
    )
}

const Home = () => {
  const navigate = useNavigate();
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Banner */}
      <div className="relative rounded-2xl overflow-hidden bg-gray-900 text-white h-64 shadow-lg group">
        <img 
          src="https://picsum.photos/id/493/1000/400" 
          alt="Banner" 
          className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" 
        />
        <div className="absolute inset-0 flex flex-col justify-center px-8">
          <span className="bg-brand-500 text-xs font-bold px-2 py-1 rounded w-fit mb-3">今日公告</span>
          <h2 className="text-3xl font-bold mb-2">网络维护与月度更新</h2>
          <p className="text-gray-200 max-w-lg mb-6">为了提供更流畅的AI对话体验，我们将于本周日进行系统升级...</p>
          <button className="bg-white text-gray-900 px-6 py-2 rounded-full font-bold w-fit hover:bg-brand-50 transition-colors">查看详情</button>
        </div>
      </div>

      {/* Categories */}
      <div className="mb-4">
          <CategoryFilter onSelect={(cat) => console.log('Selected:', cat)} />
      </div>

      {/* Recommendations */}
      <div>
        <div className="flex justify-between items-end mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-800 dark:text-white flex items-center gap-2">
              <Sparkles className="text-brand-500" size={20} />
              智能推荐食谱
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{new Date().toLocaleDateString()} · 基于您的健康数据</p>
          </div>
          <button className="text-brand-600 text-sm font-medium hover:underline">查看更多</button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {MOCK_RECIPES.map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} onClick={(id) => navigate(`/recipe/${id}`)} />
          ))}
        </div>
      </div>
    </div>
  );
};

// --- Layout Shell ---
const Layout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [showChat, setShowChat] = useState(false);
  const [notifications] = useState(MOCK_INSIGHTS);
  const [showNotif, setShowNotif] = useState(false);
  const [showAttribution, setShowAttribution] = useState(false);
  const [isDark, setIsDark] = useState(false);

  const toggleDark = () => {
      setIsDark(!isDark);
      document.documentElement.classList.toggle('dark');
  };

  const isActive = (path: string) => location.pathname === path ? 'bg-brand-50 dark:bg-gray-800 text-brand-600 dark:text-brand-400' : 'text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800';

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 font-sans transition-colors duration-300">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-white dark:bg-gray-900 border-r border-gray-100 dark:border-gray-800 fixed h-full z-10">
        <div className="p-8 flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center text-white font-bold text-xl">D</div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white tracking-tight">Diet<span className="text-brand-500">Master</span></h1>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          <button onClick={() => navigate('/')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/')}`}>
            <LayoutDashboard size={20} /> 首页
          </button>
          <button onClick={() => navigate('/plan')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/plan')}`}>
            <Utensils size={20} /> 膳食计划
          </button>
          <button onClick={() => navigate('/pantry')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/pantry')}`}>
            <Refrigerator size={20} /> 智能冰箱
          </button>
          <button onClick={() => navigate('/community')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/community')}`}>
            <Users size={20} /> 社区广场
          </button>
          <button onClick={() => navigate('/challenges')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/challenges')}`}>
            <Trophy size={20} /> 挑战中心
          </button>
          <button onClick={() => navigate('/report')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/report')}`}>
            <FileText size={20} /> 健康周报
          </button>
          <button onClick={() => navigate('/favorites')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/favorites')}`}>
            <Heart size={20} /> 我的收藏
          </button>
          <button onClick={() => navigate('/profile')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/profile')}`}>
            <UserIcon size={20} /> 个人中心
          </button>
          <button onClick={() => navigate('/settings')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${isActive('/settings')}`}>
            <SettingsIcon size={20} /> 设置
          </button>
        </nav>

        <div className="p-4 border-t border-gray-100 dark:border-gray-800">
           <button onClick={() => { localStorage.clear(); navigate('/login'); }} className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all font-medium">
             <LogOut size={20} /> 退出登录
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-md sticky top-0 z-20 border-b border-gray-100 dark:border-gray-800 px-8 py-4 flex justify-between items-center">
            <div className="flex-1 max-w-md">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input 
                        type="text" 
                        placeholder="搜索菜谱、食材..." 
                        className="w-full bg-gray-100 dark:bg-gray-800 pl-10 pr-4 py-2 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-brand-200 dark:text-white transition-all"
                    />
                </div>
            </div>

            <div className="flex items-center gap-6">
                <button onClick={toggleDark} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400">
                    {isDark ? <Sun size={20} /> : <Moon size={20} />}
                </button>

                <div className="relative">
                    <button onClick={() => setShowNotif(!showNotif)} className="relative p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
                        <Bell size={20} className="text-gray-600 dark:text-gray-400" />
                        {notifications.some(n => !n.isRead) && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-gray-900"></span>}
                    </button>
                    {showNotif && (
                        <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 overflow-hidden animate-fade-in-up">
                            {/* ... Notif content ... */}
                            <div className="p-4 text-sm text-gray-500 text-center">暂无新通知</div>
                        </div>
                    )}
                </div>

                <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/profile')}>
                    <span className="text-sm font-bold text-gray-700 dark:text-gray-200 hidden md:block">{MOCK_USER.name}</span>
                    <img src={MOCK_USER.avatar} className="w-9 h-9 rounded-full border border-gray-200 dark:border-gray-700" alt="Avatar" />
                </div>
            </div>
        </header>

        {/* Page Content */}
        <div className="p-4 md:p-8 overflow-y-auto">
             <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/plan" element={<MealPlan />} />
                <Route path="/pantry" element={<Pantry />} />
                <Route path="/report" element={<WeeklyReport />} />
                <Route path="/favorites" element={<Favorites />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/community" element={<CommunityFeed />} />
                <Route path="/challenges" element={<ChallengeCenter />} />
                <Route path="/recipe/:id" element={<RecipeDetail />} />
                <Route path="/cooking/:id" element={<CookingMode />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="*" element={<Navigate to="/" />} />
             </Routes>
        </div>
      </main>

      {!showChat && (
        <button 
            onClick={() => setShowChat(true)}
            className="fixed bottom-8 right-8 bg-brand-600 text-white p-4 rounded-full shadow-lg shadow-brand-500/40 hover:scale-110 transition-transform z-30 flex items-center gap-2 group"
        >
            <BotIcon />
            <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 whitespace-nowrap text-sm font-bold">智能管家</span>
        </button>
      )}

      <ChatInterface isOpen={showChat} onClose={() => setShowChat(false)} />
      <AttributionModal isOpen={showAttribution} onClose={() => setShowAttribution(false)} data={null} />
      <Toaster position="top-center" richColors />
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/*" element={<Layout />} />
      </Routes>
    </Router>
  );
};

export default App;