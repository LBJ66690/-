import React from 'react';

interface FoodGradeBadgeProps {
  calories: number;
  fat: number;
  className?: string;
  showLabel?: boolean;
}

const FoodGradeBadge: React.FC<FoodGradeBadgeProps> = ({ calories, fat, className = '', showLabel = true }) => {
  // Logic: 
  // Green: < 150kcal AND < 5g fat
  // Red: > 300kcal OR > 15g fat
  // Yellow: Else
  
  let grade = 'B';
  let colorClass = 'bg-yellow-100 text-yellow-700 border-yellow-200';
  let dotClass = 'bg-yellow-500';
  let label = 'B级·适量';

  if (calories < 150 && fat < 5) {
    grade = 'A';
    colorClass = 'bg-green-100 text-green-700 border-green-200';
    dotClass = 'bg-green-500';
    label = 'A级·推荐';
  } else if (calories > 300 || fat > 15) {
    grade = 'C';
    colorClass = 'bg-red-100 text-red-700 border-red-200';
    dotClass = 'bg-red-500';
    label = 'C级·少吃';
  }

  return (
    <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full border shadow-sm backdrop-blur-md ${colorClass} ${className}`}>
      <div className={`w-2 h-2 rounded-full ${dotClass} animate-pulse-slow`}></div>
      <span className="text-[10px] font-bold tracking-tight">
        {showLabel ? label : grade}
      </span>
    </div>
  );
};

export default FoodGradeBadge;